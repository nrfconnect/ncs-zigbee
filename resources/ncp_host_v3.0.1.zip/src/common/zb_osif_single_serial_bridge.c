/*
 * ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2023 DSR Corporation, Denver CO, USA.
 * http://www.dsr-zboss.com
 * http://www.dsr-corporation.com
 * All rights reserved.
 *
 *
 * Use in source and binary forms, redistribution in binary form only, with
 * or without modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 2. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 3. This software must only be used in or with a processor manufactured by Nordic
 *    Semiconductor ASA, or in or with a processor manufactured by a third party that
 *    is used in combination with a processor manufactured by Nordic Semiconductor.
 *
 * 4. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/* PURPOSE: Implements wrappers for multi-serial routines if platform doesn't support it.
*/

#define ZB_TRACE_FILE_ID 9375

#include "zb_common.h"

#if !defined(ZB_HAVE_MULTI_SERIAL)

/* Need this cb only for async serial*/
#if defined ZB_HAVE_ASYNC_SERIAL
static zb_mserial_recv_data_cb_t cb_holder = NULL;
#endif /* ZB_HAVE_ASYNC_SERIAL */

/* Definitions for the single-port serial interface how it was declared earlier */
void zb_osif_serial_init();
void zb_osif_serial_deinit();
void zb_osif_set_uart_byte_received_cb(zb_callback_t hnd);
void zb_osif_set_user_io_buffer(zb_byte_array_t *buf_ptr, zb_ushort_t capacity);
void zb_osif_serial_put_bytes(const zb_uint8_t *buf, zb_short_t len);

/**
 * @brief Wrapper for zb_osif_serial_init
 *
 * @param portname ignored
 * @param speed ignored
 * @return zb_serial_port_t Always 0
 */
zb_serial_port_t zb_osif_mserial_open(const char *portname, zb_uint32_t speed)
{
    ZVUNUSED(portname);
    ZVUNUSED(speed);
    zb_osif_serial_init();
    return 0;
}

zb_serial_port_t zb_osif_mserial_create_pty(const char *symlink, zb_uint32_t speed)
{
    return zb_osif_mserial_open(symlink, speed);
}

/**
 * @brief Wrapper for zb_osif_serial_deinit
 *
 * @param port_instance ignored
 */
void zb_osif_mserial_close(zb_serial_port_t port_instance)
{
    ZVUNUSED(port_instance);
    zb_osif_serial_deinit();
}

/**
 * @brief Wrapper for zb_osif_set_uart_byte_received_cb
 *
 * @param port_instance ignored
 * @param hnd callback to be provided to the zb_osif_set_uart_byte_received_cb() functions
 */
void zb_osif_mserial_set_byte_received_cb(zb_serial_port_t port_instance, zb_callback_t hnd)
{
    ZVUNUSED(port_instance);
    zb_osif_set_uart_byte_received_cb(hnd);
}

/**
 * @brief Wrapper for zb_osif_set_user_io_buffer
 *
 * @param port_instance ignored
 * @param buf_ptr Will be provided to the zb_osif_set_user_io_buffer()
 * @param capacity Will be provided to the zb_osif_set_user_io_buffer()
 */
void zb_osif_mserial_set_user_io_buffer(zb_serial_port_t port_instance, zb_byte_array_t *buf_ptr, zb_ushort_t capacity)
{
    ZVUNUSED(port_instance);
    zb_osif_set_user_io_buffer(buf_ptr, capacity);
}

/**
 * @brief Wrapper for zb_osif_serial_put_bytes
 *
 * @param port_instance ignored
 * @param buf Will be provided to the zb_osif_serial_put_bytes()
 * @param len Will be provided to the zb_osif_serial_put_bytes()
 */
void zb_osif_mserial_put_bytes(zb_serial_port_t port_instance, const zb_uint8_t *buf, zb_short_t len)
{
  ZVUNUSED(port_instance);
  zb_osif_serial_put_bytes(buf, len);
}

#if defined(ZB_HAVE_ASYNC_SERIAL)

typedef void (*zb_serial_recv_data_cb_t)(zb_uint8_t *buf, zb_ushort_t len);
void zb_osif_serial_recv_data(zb_uint8_t *buf, zb_ushort_t len);
void zb_osif_serial_set_cb_recv_data(zb_serial_recv_data_cb_t cb);
void zb_osif_serial_send_data(zb_uint8_t *buf, zb_ushort_t len);
void zb_osif_serial_set_cb_send_data(zb_serial_send_data_cb_t cb);

/**
 * @brief Wrapper for zb_osif_serial_recv_data
 *
 * @param port_instance
 * @param buf Will be provided to the zb_osif_serial_recv_data
 * @param len Will be provided to the zb_osif_serial_recv_data
 */
void zb_osif_mserial_recv_data(zb_serial_port_t port_instance, zb_uint8_t *buf, zb_ushort_t len)
{
    ZVUNUSED(port_instance);
    zb_osif_serial_recv_data(buf, len);
}

/**
 * @brief A handler dispatching all events to registered handler.
 *
 * @param buf Will be provided to the user callback
 * @param len Will be provided to the user callback
 */
void default_cb_recv_data(zb_uint8_t *buf, zb_ushort_t len)
{
    if (cb_holder != NULL)
    {
        cb_holder(0, buf, len);
    }
}

/**
 * @brief Wrapper for zb_osif_serial_set_cb_recv_data
 *
 * @param port_instance ignored
 * @param cb User callback. Should be called when data received.
 */
void zb_osif_mserial_set_cb_recv_data(zb_serial_port_t port_instance, zb_mserial_recv_data_cb_t cb)
{
    cb_holder = cb;
    ZVUNUSED(port_instance);
    zb_osif_serial_set_cb_recv_data(default_cb_recv_data);
}

/**
 * @brief Wrapper for zb_osif_serial_send_data
 *
 * @param port_instance ignored
 * @param buf Will be provided to the zb_osif_serial_send_data
 * @param len Will be provided to the zb_osif_serial_send_data
 */
void zb_osif_mserial_send_data(zb_serial_port_t port_instance, zb_uint8_t *buf, zb_ushort_t len)
{
    ZVUNUSED(port_instance);
    zb_osif_serial_send_data(buf, len);
}

/**
 * @brief Wrapper for zb_osif_serial_set_cb_send_data
 *
 * @param port_instance ignored
 * @param cb Will be provided to the zb_osif_serial_set_cb_send_data
 */
void zb_osif_mserial_set_cb_send_data(zb_serial_port_t port_instance, zb_serial_send_data_cb_t cb)
{
    ZVUNUSED(port_instance);
    zb_osif_serial_set_cb_send_data(cb);
}
#endif /* ZB_HAVE_ASYNC_SERIAL */

#endif /* !ZB_HAVE_MULTI_SERIAL */
