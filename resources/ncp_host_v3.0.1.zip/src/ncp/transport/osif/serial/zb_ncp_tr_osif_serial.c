/*
 * ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2024 DSR Corporation, Denver CO, USA.
 * http://www.dsr-zboss.com
 * http://www.dsr-corporation.com
 * All rights reserved.
 *
 *
 * Use in source and binary forms, redistribution in binary form only, with
 * or without modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 2. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 3. This software must only be used in or with a processor manufactured by Nordic
 *    Semiconductor ASA, or in or with a processor manufactured by a third party that
 *    is used in combination with a processor manufactured by Nordic Semiconductor.
 *
 * 4. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/* PURPOSE: NCP transport for OSIF serial, low level.
*/

#define ZB_TRACE_FILE_ID 14010
#include "zb_common.h"
#include "transport/zb_ncp_tr.h"
#include "zb_osif.h"

/* That code is a complete mess... refactor it. Divide by files depending on build options */

#if defined(ZB_NCP_TRANSPORT_TYPE_SERIAL) || defined(ZB_NCP_TRANSPORT_TYPE_USERIAL)


#if defined ZB_NCP_TRANSPORT_TYPE_SERIAL

#ifndef ZB_MAC_TRANSPORT_UART_SPEED
#define ZB_MAC_TRANSPORT_UART_SPEED (115200UL)
#endif

#if defined NCP_MODE_HOST
#define SERIAL_PORT_INIT_FUNC zb_osif_mserial_open
#else
#define SERIAL_PORT_INIT_FUNC zb_osif_mserial_create_pty
#endif

/* Use unified initialization for devices that have one or more serial ports used by ZBOSS.
 * Only one serial port is used by default on HW,
 * and `zb_osif_serial_init` will be called from `zb_osif_mserial_open` in such case.
 */
#if defined(ZB_PLATFORM_LINUX)
#define SERIAL_INIT() do {g_ncp_port = SERIAL_PORT_INIT_FUNC(zb_ncp_uart_path(), ZB_MAC_TRANSPORT_UART_SPEED); } while (0)
#else
#define SERIAL_INIT() do {g_ncp_port = SERIAL_PORT_INIT_FUNC("", ZB_MAC_TRANSPORT_UART_SPEED); } while (0)
#endif /* ZB_PLATFORM_LINUX */

#define PUT_BYTES(a,b) zb_osif_serial_transport_put_bytes(a,b)
#define SEND_DATA(a,b) zb_osif_mserial_send_data(g_ncp_port, a, b)
#define RECV_DATA(a,b) zb_osif_mserial_recv_data(g_ncp_port, a, b)
#define SET_IO_BUFFER(a, b) zb_osif_mserial_set_user_io_buffer(g_ncp_port, a, b)
#define SET_BYTE_RECV_CB(a) zb_osif_mserial_set_byte_received_cb(SERIAL_PORT_INVALID, a)
#define SET_SEND_CB(a) zb_osif_mserial_set_cb_send_data(g_ncp_port, a)
#define SET_RECV_CB(a) zb_osif_mserial_set_cb_recv_data(g_ncp_port, a)

#elif defined ZB_NCP_TRANSPORT_TYPE_USERIAL

#define PUT_BYTES zb_osif_userial_put_bytes
#define SEND_DATA zb_osif_userial_send_data
#define RECV_DATA zb_osif_userial_recv_data
#define SET_IO_BUFFER(a, b)
#define SET_BYTE_RECV_CB zb_osif_set_userial_byte_received_cb
#define SET_SEND_CB zb_osif_userial_set_cb_send_data
#define SET_RECV_CB zb_osif_userial_set_cb_recv_data
#define SERIAL_INIT zb_osif_userial_init

#endif /* ZB_NCP_TRANSPORT_TYPE_SERIAL */

typedef struct zbncp_transport_impl_s
{
  zbncp_transport_ops_t ops;
  zbncp_transport_cb_t cb;
} ncp_tr_impl_t;

static ncp_tr_impl_t s_ncp_tr;

#ifdef ZB_NCP_TRANSPORT_TYPE_SERIAL
static zb_serial_port_t g_ncp_port = SERIAL_PORT_INVALID;
#endif


#ifndef ZB_HAVE_ASYNC_SERIAL
#define SERIAL_RX_BYTE_TIMEOUT ZB_MILLISECONDS_TO_BEACON_INTERVAL(100)

#ifdef ZB_NCP_USE_OSIF_RX_BUFFER

#ifndef ZB_NCP_TRANSPORT_BUFFER_CAPACITY
#define ZB_NCP_TRANSPORT_BUFFER_CAPACITY 255U
#endif
ZB_RING_BUFFER_DECLARE(zb_ncp_transport_buffer, zb_uint8_t, ZB_NCP_TRANSPORT_BUFFER_CAPACITY);
static zb_ncp_transport_buffer_t ncp_osif_rx_buffer;
static volatile zb_bool_t ncp_osif_rx_buffer_flush_scheduled = ZB_FALSE;
static void ncp_osif_rx_buf_schedule_flush(void);
#endif /* ZB_NCP_USE_RX_BUFFER */

static volatile zbncp_memref_t s_rx_buf;
static volatile zbncp_size_t s_rx_offset;
static volatile zb_time_t s_rx_timestamp;

static void serial_rx_timeout(zb_bufid_t bufid)
{
  const ncp_tr_impl_t *tr = &s_ncp_tr;
  (void)(bufid);

  ZB_SCHEDULE_APP_ALARM_CANCEL(serial_rx_timeout, ZB_ALARM_ANY_PARAM);

  if ((s_rx_buf.ptr != NULL) &&
      (tr->cb.recv))
  {
    if ((s_rx_offset == s_rx_buf.size) ||
        ((ZB_TIME_SUBTRACT(ZB_TIMER_GET(), s_rx_timestamp) >= SERIAL_RX_BYTE_TIMEOUT) &&
        (s_rx_offset > 0)))
    {
      TRACE_MSG(TRACE_COMMON3, "Serial RX timeout: recv cb %p len %d", (FMT__P_D, tr->cb.recv, (zb_uint_t)s_rx_offset));
      tr->cb.recv(tr->cb.arg, s_rx_offset);
    }
  }

  /* Reschedule RX byte timeout alarm to handle nonsynchronized, partial transmissions. */
  ZB_SCHEDULE_APP_ALARM(serial_rx_timeout, 0, SERIAL_RX_BYTE_TIMEOUT);
}


/*
 * Places the next byte in the NCP buffer, checks that the NCP
 * buffer is full and schedules the next transmission (cb.recv()).
 *
 * Returns true if NCP buffer is full
 *
 * Can only be called if there is room in the NCP buffer.
 */
static zb_bool_t serial_rx_byte_handler(zb_uint8_t byte)
{
  zb_bool_t ret = ZB_FALSE;

  if (s_rx_offset < s_rx_buf.size)
  {
    s_rx_timestamp = ZB_TIMER_GET();
    ((zb_uint8_t*)s_rx_buf.ptr)[s_rx_offset++] = byte;
    if (s_rx_offset == s_rx_buf.size)
    {
      ZB_SCHEDULE_APP_CALLBACK(serial_rx_timeout, 0);
      ret = ZB_TRUE;
    }
  }
  else
  {
    ZB_ASSERT(0);
  }

  return ret;
}

#ifdef ZB_NCP_USE_OSIF_RX_BUFFER
static void ncp_osif_rx_buffer_flush(zb_uint8_t param)
{
  zb_uint8_t byte;

  (void)param;

  ncp_osif_rx_buffer_flush_scheduled = ZB_FALSE;
  if (s_rx_offset < s_rx_buf.size)
  {
    while (!ZB_RING_BUFFER_IS_EMPTY(&ncp_osif_rx_buffer))
    {
      byte = *ZB_RING_BUFFER_GET(&ncp_osif_rx_buffer);

      ZB_SERIAL_INT_DISABLE();
      ZB_RING_BUFFER_FLUSH_GET(&ncp_osif_rx_buffer);
      ZB_SERIAL_INT_ENABLE();

      if (serial_rx_byte_handler(byte))
      {
        /* NCP buffer is full */
        break;
      }
    }
  }

  TRACE_MSG(TRACE_COMMON4, "ncp_osif_rx_buffer_flush remaining %u bytes",
            (FMT__D, ZB_RING_BUFFER_USED_SPACE(&ncp_osif_rx_buffer)));

  if (!ZB_RING_BUFFER_IS_EMPTY(&ncp_osif_rx_buffer))
  {
    /* If something is left in the buffer,
     * it is safe to schedule itself again.
     */
    ncp_osif_rx_buf_schedule_flush();
  }
}

static void ncp_osif_rx_buf_schedule_flush(void)
{
  if (!ncp_osif_rx_buffer_flush_scheduled)
  {
    ZB_SCHEDULE_APP_CALLBACK(ncp_osif_rx_buffer_flush, 0);
    ncp_osif_rx_buffer_flush_scheduled = ZB_TRUE;
  }
}
#endif

static void serial_osif_rx_byte_handler(zb_uint8_t byte)
{
  if (s_rx_buf.ptr != NULL)
  {
#ifndef ZB_NCP_USE_OSIF_RX_BUFFER
    if (s_rx_offset < s_rx_buf.size)
    {
      serial_rx_byte_handler(byte);
    }
    else
    {
      TRACE_MSG(TRACE_ERROR, "NCP buffer is full, byte is dropped", (FMT__0));
    }
#else
    if (ZB_RING_BUFFER_IS_EMPTY(&ncp_osif_rx_buffer) && s_rx_offset < s_rx_buf.size)
    {
      /* Place byte in NCP buffer immediately if intermediate
       * buffer is empty and there is room in the NCP buffer.
       */
      serial_rx_byte_handler(byte);
    }
    else
    {
      if (ZB_RING_BUFFER_IS_FULL(&ncp_osif_rx_buffer))
      {
        TRACE_MSG(TRACE_ERROR, "ncp_osif_rx_buffer is full", (FMT__0));
        ZB_ASSERT(0);
      }
      else
      {
        ZB_RING_BUFFER_PUT(&ncp_osif_rx_buffer, byte);
        ncp_osif_rx_buf_schedule_flush();
      }
    }
#endif
  }
}

#else /* ZB_HAVE_ASYNC_SERIAL */

static void ncp_tr_send_complete(zb_uint8_t tx_status)
{
  const ncp_tr_impl_t *tr = &s_ncp_tr;
  zbncp_tr_send_status_t status = ZBNCP_TR_SEND_STATUS_ERROR;

  switch (tx_status)
  {
    case SERIAL_SEND_SUCCESS:
      status = ZBNCP_TR_SEND_STATUS_SUCCESS;
      break;
    case SERIAL_SEND_BUSY:
      status = ZBNCP_TR_SEND_STATUS_BUSY;
      break;
    case SERIAL_SEND_TIMEOUT_EXPIRED:
      status = ZBNCP_TR_SEND_STATUS_TIMEOUT;
      break;
    case SERIAL_SEND_ERROR:
      /* fall-through: handle all unsupported status as errors. */
    default:
      status = ZBNCP_TR_SEND_STATUS_ERROR;
      break;
  }

  if (tr->cb.send)
  {
    TRACE_MSG(TRACE_COMMON3, "Serial TX: cb %p status %d", (FMT__P_D, tr->cb.send, (zb_uint_t)status));
    tr->cb.send(tr->cb.arg, status);
  }
}

static void ncp_tr_recv_complete(zb_serial_port_t port_instance, zb_uint8_t *buf, zb_ushort_t len)
{
  const ncp_tr_impl_t *tr = &s_ncp_tr;

  ZVUNUSED(port_instance);

  if (tr->cb.recv)
  {
    TRACE_MSG(TRACE_COMMON3, "Serial RX: cb %p len %d", (FMT__P_D, tr->cb.recv, (zb_uint_t)len));
    tr->cb.recv(tr->cb.arg, len);
  }

  (void) buf;
}
#endif


static void ncp_tr_init(ncp_tr_impl_t *tr, const zbncp_transport_cb_t *cb)
{
  TRACE_MSG(TRACE_COMMON2, ">ncp_tr_init - ZBOSS FW NCP transport starting", (FMT__0));

  tr->cb = *cb;

#ifndef ZB_HAVE_ASYNC_SERIAL
  SERIAL_INIT();
  s_rx_buf.ptr = NULL;
  s_rx_offset = 0;
#ifdef ZB_NCP_USE_OSIF_RX_BUFFER
  ZB_RING_BUFFER_INIT(&ncp_osif_rx_buffer);
#endif
  SET_BYTE_RECV_CB(serial_osif_rx_byte_handler);
#else
  SERIAL_INIT();
  SET_SEND_CB(ncp_tr_send_complete);
  SET_RECV_CB(ncp_tr_recv_complete);
#endif /* ZB_HAVE_ASYNC_SERIAL */

  if (tr->cb.init)
  {
    TRACE_MSG(TRACE_COMMON1, "Serial initialized: cb %p", (FMT__P, tr->cb.init));
    tr->cb.init(tr->cb.arg);
  }
  TRACE_MSG(TRACE_COMMON2, "<ncp_tr_init", (FMT__0));
}


static void ncp_tr_send(ncp_tr_impl_t *tr, zbncp_cmemref_t mem)
{
  TRACE_MSG(TRACE_COMMON3, ">ncp_tr_send data %p len %d", (FMT__P_D, mem.ptr, (zb_uint_t)mem.size));
  (void)tr;

#ifndef ZB_HAVE_ASYNC_SERIAL
  PUT_BYTES((zb_uint8_t *)mem.ptr, (zb_ushort_t)mem.size);
  if (tr->cb.send)
  {
    TRACE_MSG(TRACE_COMMON3, "Serial TX: cb %p status %d", (FMT__P_D, tr->cb.send, (zb_uint_t)ZBNCP_TR_SEND_STATUS_SUCCESS));
    tr->cb.send(tr->cb.arg, ZBNCP_TR_SEND_STATUS_SUCCESS);
  }
#else
  SEND_DATA((zb_uint8_t *)mem.ptr, (zb_ushort_t)mem.size);
#endif
  TRACE_MSG(TRACE_COMMON3, "<ncp_tr_send", (FMT__0));
}


/*
zbncp_ll_impl.c calls that function when it wants something to receive.
It specifies in mem only number of bytes it is ready to recv. For example, receiving a packet, it first ncp_tr_recv to recv just a header.
So the transport must buffer received data itself.
*/
static void ncp_tr_recv(ncp_tr_impl_t *tr, zbncp_memref_t mem)
{
  (void)tr;
  TRACE_MSG(TRACE_COMMON3, ">ncp_tr_recv data %p len %d", (FMT__P_D, mem.ptr, (zb_uint_t)mem.size));
#ifndef ZB_HAVE_ASYNC_SERIAL
  /* Serial always receives data byte-by-byte without bufferring. Fill RX buffer inside byte handler. */
  ZB_SCHEDULE_APP_ALARM_CANCEL(serial_rx_timeout, ZB_ALARM_ANY_PARAM);
  s_rx_buf = mem;
  s_rx_offset = 0;
  s_rx_timestamp = ZB_TIMER_GET();
  ZB_SCHEDULE_APP_ALARM(serial_rx_timeout, 0, SERIAL_RX_BYTE_TIMEOUT);
#else
  RECV_DATA((zb_uint8_t *)mem.ptr, (zb_ushort_t)mem.size);
#endif
  TRACE_MSG(TRACE_COMMON3, "<ncp_tr_recv", (FMT__0));
}

#if defined NCP_MODE_HOST
const zbncp_transport_ops_t *ncp_host_transport_create(void)
#else
const zbncp_transport_ops_t *ncp_dev_transport_create(void)
#endif
{
#if defined NCP_HOST_SHARED_LIB && !defined DISABLE_TRACE_INIT
  TRACE_INIT("ncp_host_ll_so");
  TRACE_MSG(TRACE_COMMON3, ">>ncp_host_transport_create", (FMT__0));
#endif /* NCP_HOST_SHARED_LIB && !DISABLE_TRACE_INIT */
  s_ncp_tr.ops.impl = &s_ncp_tr;
  s_ncp_tr.ops.init = ncp_tr_init;
  s_ncp_tr.ops.send = ncp_tr_send;
  s_ncp_tr.ops.recv = ncp_tr_recv;
  return &s_ncp_tr.ops;
}

#endif /* defined(ZB_NCP_TRANSPORT_TYPE_SERIAL) || defined(ZB_NCP_TRANSPORT_TYPE_USERIAL) */
