/*
 * ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2024 DSR Corporation, Denver CO, USA.
 * http://www.dsr-zboss.com
 * http://www.dsr-corporation.com
 * All rights reserved.
 *
 *
 * Use in source and binary forms, redistribution in binary form only, with
 * or without modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 2. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 3. This software must only be used in or with a processor manufactured by Nordic
 *    Semiconductor ASA, or in or with a processor manufactured by a third party that
 *    is used in combination with a processor manufactured by Nordic Semiconductor.
 *
 * 4. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/*  PURPOSE: NCP High level transport (adapters layer) implementation for the host side: NWK category
*/
#define ZB_TRACE_FILE_ID 17510

#include "ncp_host_hl_transport_internal_api.h"
#include "ncp_host_soc_state.h"
#include "zb_zdo.h"


typedef ZB_PACKED_PRE struct nwk_nbr_itarator_next_data_s
{
  zb_callback_t cb;
  zb_bufid_t    buf;
}
ZB_PACKED_STRUCT nwk_nbr_itarator_next_data_t;

typedef ZB_PACKED_PRE struct nwkmgmt_adapter_ctx_s
{
  nwk_nbr_itarator_next_data_t nbr_iterator; /*!< Static values, used to store the callback as well as its parameters. */
  zb_callback_t panid_change_ctx_cb;
}
ZB_PACKED_STRUCT nwkmgmt_adapter_ctx_t;

static nwkmgmt_adapter_ctx_t g_adapter_ctx;

void ncp_host_nwkmgmt_adapter_init_ctx(void)
{
  ZB_BZERO(&g_adapter_ctx, sizeof(g_adapter_ctx));
}


#ifdef ZB_FORMATION

void zb_nlme_network_formation_request(zb_bufid_t buf)
{
  zb_ret_t ret = RET_BUSY;
  zb_nlme_network_formation_request_t *req = ZB_BUF_GET_PARAM(buf, zb_nlme_network_formation_request_t);

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_nlme_network_formation_request", (FMT__0));

  ncp_host_state_set_joined(ZB_TRUE);
  ncp_host_state_set_authenticated(ZB_TRUE);
  ncp_host_state_set_tclk_valid(ZB_TRUE);

  if (ZB_IEEE_ADDR_IS_ZERO(req->extpanid))
  {
    ncp_host_state_get_long_addr(req->extpanid);
  }

  ncp_host_state_set_extended_pan_id(req->extpanid);

  ret = ncp_host_nwk_formation(req->scan_channels_list, req->scan_duration,
                               req->distributed_network, req->distributed_network_address, req->extpanid);
  ZB_ASSERT(ret == RET_OK);

  zb_buf_free(buf);

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_nlme_network_formation_request, ret %d", (FMT__D, ret));
}


void zb_nwk_cont_without_formation(zb_uint8_t param)
{
  zb_ret_t ret = RET_BUSY;

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_nwk_cont_without_formation", (FMT__0));

  ncp_host_state_set_joined(ZB_TRUE);

  ret = ncp_host_nwk_start_without_formation();
  ZB_ASSERT(ret == RET_OK);

  zb_buf_free(param);

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_nwk_cont_without_formation, ret %d", (FMT__D, ret));
}

#endif /* ZB_FORMATION */

#ifdef ZB_ROUTER_ROLE

void zb_zdo_start_router(zb_uint8_t param)
{
  zb_ret_t ret;

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_zdo_start_router", (FMT__0));

  zb_buf_free(param);

  ret = ncp_host_nwk_nlme_start_router_request(ZB_TURN_OFF_ORDER, ZB_TURN_OFF_ORDER, 0);
  ZB_ASSERT(ret == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_zdo_start_router", (FMT__0));
}

#endif /* ZB_ROUTER_ROLE */


#ifdef ZB_JOIN_CLIENT

void zb_nlme_leave_request(zb_uint8_t param)
{
  ZVUNUSED(param);
  /* We don't use and should not use this function for NCP Host */

  ZB_ASSERT(0);
}

#endif /* ZB_JOIN_CLIENT */

void zb_nlme_network_discovery_request(zb_bufid_t buf)
{
  zb_ret_t ret = RET_BUSY;
  zb_nlme_network_discovery_request_t *req = ZB_BUF_GET_PARAM(buf, zb_nlme_network_discovery_request_t);

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_nlme_network_discovery_request", (FMT__0));

  ret = ncp_host_nwk_discovery(req->scan_channels_list, req->scan_duration);
  ZB_ASSERT(ret == RET_OK);

  zb_buf_free(buf);

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_nlme_network_discovery_request, ret %d", (FMT__D, ret));
}

void zb_nlme_join_request(zb_bufid_t buf)
{
  zb_ret_t ret = RET_BUSY;
  zb_nlme_join_request_t *req = ZB_BUF_GET_PARAM(buf, zb_nlme_join_request_t);

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_nlme_join_request", (FMT__0));

  ret = ncp_host_nwk_nlme_join(req->extended_pan_id, (zb_uint8_t)req->rejoin_network,
                               req->scan_channels_list, req->scan_duration,
                               (zb_uint8_t)req->capability_information, req->security_enable);
  ZB_ASSERT(ret == RET_OK);

  zb_buf_free(buf);

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_nlme_join_request, ret %d", (FMT__D, ret));
}


/* Set Keepalive Timeout */
void zb_set_keepalive_timeout(zb_uint_t timeout)
{
  zb_ret_t ret = RET_BUSY;

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_set_keepalive_timeout", (FMT__0));

#if 0

  if (ncp_host_state_get_zboss_started())
  {
    ret = ncp_host_set_keepalive_timeout(timeout);
    ZB_ASSERT(ret == RET_OK);
  }
  else
  {
    ncp_host_state_set_keepalive_timeout(timeout);
  }

#else
  ZVUNUSED(timeout);
#endif

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_set_keepalive_timeout, ret %d", (FMT__D, ret));
}


/* Set End Device Timeout */
void zb_set_ed_timeout(zb_uint_t timeout)
{
  zb_ret_t ret = RET_BUSY;

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_set_ed_timeout", (FMT__0));

  if (ncp_host_state_get_zboss_started())
  {
    ret = ncp_host_set_end_device_timeout(timeout);
    ZB_ASSERT(ret == RET_OK);
  }
  else
  {
    ncp_host_state_set_ed_timeout(timeout);
  }

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_set_ed_timeout, ret %d", (FMT__D, ret));
}


/* Set Keepalive Mode */
void zb_set_keepalive_mode(nwk_keepalive_supported_method_t mode)
{
  zb_ret_t ret = RET_BUSY;

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_set_keepalive_mode", (FMT__0));

  if (ncp_host_state_get_zboss_started())
  {
    ret = ncp_host_nwk_set_keepalive_mode(mode);
    ZB_ASSERT(ret == RET_OK);
  }
  else
  {
    ncp_host_state_set_keepalive_mode(mode);
  }

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_set_keepalive_mode, ret %d", (FMT__D, ret));
}


void zb_start_concentrator_mode(zb_uint8_t radius, zb_uint32_t disc_time)
{
  zb_ret_t ret = RET_BUSY;

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_start_concentrator_mode", (FMT__0));

  ret = ncp_host_nwk_start_concentrator_mode(radius, disc_time);
  ZB_ASSERT(ret == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_start_concentrator_mode, ret %d", (FMT__D, ret));
}


void zb_stop_concentrator_mode(void)
{
  zb_ret_t ret = RET_BUSY;

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_stop_concentrator_mode", (FMT__0));

  ret = ncp_host_nwk_stop_concentrator_mode();
  ZB_ASSERT(ret == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_stop_concentrator_mode, ret %d", (FMT__D, ret));
}


void zb_start_pan_id_conflict_resolution(zb_uint8_t param)
{
  zb_ret_t ret;
  /* zb_pan_id_conflict_info_t structure was removed, so now zb_start_pan_id_conflict_resolution()
   * parameter doesn't contain information about conflict */

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_start_pan_id_conflict_resolution", (FMT__0));

  ret = ncp_host_nwk_start_pan_id_conflict_resolution();
  ZB_ASSERT(ret == RET_OK);

  zb_buf_free(param);

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_start_pan_id_conflict_resolution, ret %d", (FMT__D, ret));
}


void zb_enable_auto_pan_id_conflict_resolution(zb_bool_t status)
{
  zb_ret_t ret;

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_enable_auto_pan_id_conflict_resolution", (FMT__0));

  ret = ncp_host_nwk_enable_auto_pan_id_conflict_resolution(status);
  ZB_ASSERT(ret == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_enable_auto_pan_id_conflict_resolution, ret %d", (FMT__D, ret));
}


void zb_enable_panid_conflict_resolution(zb_bool_t status)
{
  zb_ret_t ret;

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_enable_panid_conflict_resolution", (FMT__0));

  ret = ncp_host_nwk_enable_pan_id_conflict_resolution(status);
  ZB_ASSERT(ret == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_enable_panid_conflict_resolution, ret %d", (FMT__D, ret));
}


void ncp_host_nwk_permit_joining_adapter(zb_bufid_t buf)
{
  zb_ret_t ret = RET_BUSY;
  zb_nlme_permit_joining_request_t *req = ZB_BUF_GET_PARAM(buf, zb_nlme_permit_joining_request_t);

  TRACE_MSG(TRACE_TRANSPORT2, ">> ncp_host_nwk_permit_joining_adapter", (FMT__0));

  ret = ncp_host_nwk_permit_joining(req->permit_duration);
  ZB_ASSERT(ret == RET_OK);

  zb_buf_free(buf);

  TRACE_MSG(TRACE_TRANSPORT2, "<< ncp_host_nwk_permit_joining_adapter, ret %d", (FMT__D, ret));
}


zb_ret_t zb_nwk_nbr_iterator_next(zb_uint8_t bufid, zb_callback_t cb)
{
  zb_ret_t ret = RET_OK;
  zb_nwk_nbr_iterator_params_t *args = ZB_BUF_GET_PARAM(bufid, zb_nwk_nbr_iterator_params_t);

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_nwk_nbr_iterator_next", (FMT__0));

  /* Do not allow simultaneous queries. */
  if (g_adapter_ctx.nbr_iterator.cb != NULL)
  {
    ret = RET_BUSY;
  }

  if (ret == RET_OK)
  {
    g_adapter_ctx.nbr_iterator.cb = cb;
    g_adapter_ctx.nbr_iterator.buf = bufid;

    ret = ncp_host_nwk_nbr_iterator_next(args->index, args->update_count);
    if (ret != RET_OK)
    {
      g_adapter_ctx.nbr_iterator.cb = NULL;
    }
  }

  if (ret != RET_OK)
  {
    zb_buf_free(bufid);
  }

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_nwk_nbr_iterator_next", (FMT__0));

  return ret;
}

#if defined ZB_COORDINATOR_ROLE
zb_ret_t zb_prepare_network_for_channel_pan_id_change(zb_uint8_t param, zb_callback_t cb, zb_bool_t is_panid_change)
{
  zb_ret_t ret = RET_OK;

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_prepare_network_for_channel_pan_id_change %d", (FMT__D, is_panid_change));

  /* Do not allow simultaneous queries. */
  if (g_adapter_ctx.panid_change_ctx_cb != NULL)
  {
    ret = RET_BUSY;
  }

  if (ret == RET_OK)
  {
    g_adapter_ctx.panid_change_ctx_cb = cb;

    if (is_panid_change == ZB_TRUE)
    {
      zb_panid_change_parameters_t *req = ZB_BUF_GET_PARAM(param, zb_panid_change_parameters_t);
      ret = ncp_host_zb_prepare_network_for_channel_pan_id_change(req->next_panid_change);
    }
    else
    {
      zb_channel_change_parameters_t *req = ZB_BUF_GET_PARAM(param, zb_channel_change_parameters_t);
      ret = ncp_host_zb_prepare_network_for_channel_change(req->next_channel_change);
    }

    if (ret != RET_OK)
    {
      g_adapter_ctx.panid_change_ctx_cb = NULL;
    }
  }

  zb_buf_free(param);

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_prepare_network_for_channel_pan_id_change", (FMT__0));

  return ret;
}

zb_ret_t zb_prepare_network_for_channel_change(zb_uint8_t param, zb_callback_t cb)
{
  return zb_prepare_network_for_channel_pan_id_change(param, cb, ZB_FALSE);
}

zb_ret_t zb_prepare_network_for_panid_change(zb_uint8_t param, zb_callback_t cb)
{
  return zb_prepare_network_for_channel_pan_id_change(param, cb, ZB_TRUE);
}

#endif /* ZB_COORDINATOR_ROLE */

#if defined ZB_ROUTER_ROLE
zb_ret_t zb_start_channel_change(zb_uint8_t param)
{
  zb_ret_t ret = RET_OK;
  zb_channel_change_parameters_t *req = ZB_BUF_GET_PARAM(param, zb_channel_change_parameters_t);

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_start_channel_change %d", (FMT__D, req->next_channel_change));

  ret = ncp_host_zb_start_channel_change(req->next_channel_change);

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_start_channel_change", (FMT__0));

  return ret;
}

zb_ret_t zb_start_panid_change(zb_uint8_t param)
{
  zb_ret_t ret = RET_OK;
  zb_panid_change_parameters_t *req = ZB_BUF_GET_PARAM(param, zb_panid_change_parameters_t);

  TRACE_MSG(TRACE_TRANSPORT2, ">> zb_start_panid_change", (FMT__0));

  ret = ncp_host_zb_start_panid_change(req->next_panid_change);

  TRACE_MSG(TRACE_TRANSPORT2, "<< zb_start_panid_change", (FMT__0));

  return ret;
}

#endif /* ZB_ROUTER_ROLE */

#ifdef ZB_FORMATION

void ncp_host_handle_nwk_formation_response(zb_ret_t status,
                                            zb_uint16_t short_address,
                                            zb_uint16_t pan_id,
                                            zb_uint8_t current_page,
                                            zb_uint8_t current_channel)
{
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_formation_response", (FMT__0));

  ZB_ASSERT(buf != ZB_BUF_INVALID);

  zb_buf_set_status(buf, status);

  if (status == RET_OK)
  {
    ncp_host_state_set_short_address(short_address);
    ncp_host_state_set_pan_id(pan_id);
    ncp_host_state_set_current_page(current_page);
    ncp_host_state_set_current_channel(current_channel);

    zdo_commissioning_formation_done(buf);
  }
  else
  {
    zdo_commissioning_formation_failed(buf);
  }

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_formation_response", (FMT__0));
}


void ncp_host_handle_nwk_start_without_formation_response(zb_ret_t status)
{
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_start_without_formation_response", (FMT__0));

  ZB_ASSERT(buf != ZB_BUF_INVALID);

  zb_buf_set_status(buf, status);

  zdo_commissioning_formation_done(buf);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_start_without_formation_response", (FMT__0));
}

#endif /* ZB_FORMATION */

#ifdef ZB_JOIN_CLIENT
void ncp_host_handle_nwk_discovery_response(zb_ret_t status, zb_uint8_t network_count,
                                            ncp_proto_network_descriptor_t *network_descriptors)
{
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);
  zb_nlme_network_discovery_confirm_t *cnf;
  zb_nlme_network_descriptor_t *dsc;
  zb_address_pan_id_ref_t pan_id_ref;
  zb_uint8_t i;
  zb_ret_t ret;

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_discovery_response", (FMT__0));

  ZB_ASSERT(buf != ZB_BUF_INVALID);

  zb_buf_set_status(buf, status);

  cnf = (zb_nlme_network_discovery_confirm_t *)zb_buf_begin(buf);
  cnf->status = status;
  cnf->network_count = network_count;

  dsc = (zb_nlme_network_descriptor_t *)(cnf + 1);

  for (i = 0; i < network_count; i++)
  {
    TRACE_MSG(TRACE_TRANSPORT3, "entry number %hd", (FMT__H, i));

    ZB_BZERO(&dsc[i], sizeof(*dsc));

    TRACE_MSG(TRACE_TRANSPORT3, "pan_id = 0x%d, extended_pan_id = " TRACE_FORMAT_64,
              (FMT__D_A, network_descriptors[i].pan_id,
               TRACE_ARG_64(network_descriptors[i].extended_pan_id)));

    ret = zb_address_set_pan_id(network_descriptors[i].pan_id,
                                network_descriptors[i].extended_pan_id,
                                &pan_id_ref);

    ZB_ASSERT(ret == RET_OK || ret == RET_ALREADY_EXISTS);
    if (ret == RET_OK || ret == RET_ALREADY_EXISTS)
    {
      dsc[i].panid_ref = pan_id_ref;

      /* 07/30/2020 EE CR:MINOR Why use 9 trace lines? 1 is enough. */
      dsc[i].channel_page = network_descriptors[i].channel_page;
      TRACE_MSG(TRACE_TRANSPORT3, "channel_page = %hd", (FMT__H, dsc[i].channel_page));

      dsc[i].logical_channel = network_descriptors[i].channel;
      TRACE_MSG(TRACE_TRANSPORT3, "logical_channel = %hd", (FMT__H, dsc[i].logical_channel));

      dsc[i].permit_joining = network_descriptors[i].flags & 1;
      TRACE_MSG(TRACE_TRANSPORT3, "permit_joining = %hd", (FMT__H, dsc[i].permit_joining));

      dsc[i].router_capacity = (network_descriptors[i].flags >> 1) & 1;
      TRACE_MSG(TRACE_TRANSPORT3, "router_capacity = %hd", (FMT__H, dsc[i].router_capacity));

      dsc[i].end_device_capacity = (network_descriptors[i].flags >> 2) & 1;
      TRACE_MSG(TRACE_TRANSPORT3, "end_device_capacity = %hd", (FMT__H, dsc[i].end_device_capacity));

      dsc[i].nwk_update_id = network_descriptors[i].nwk_update_id;
      TRACE_MSG(TRACE_TRANSPORT3, "nwk_update_id = %hd", (FMT__H, dsc[i].nwk_update_id));
    }
    else
    {
      /* TODO: maybe clear PAN ID table? */
      TRACE_MSG(TRACE_ERROR, "failed to save PAN ID info, drop some discovery results", (FMT__0));
      cnf->network_count = i;
      break;
    }
  }

  zdo_handle_nlme_network_discovery_confirm(buf);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_discovery_response", (FMT__0));
}

void ncp_host_handle_nwk_nlme_join_response(zb_ret_t status, zb_uint16_t short_addr,
                                            zb_ext_pan_id_t extended_pan_id,
                                            zb_uint8_t channel_page, zb_uint8_t logical_channel,
                                            zb_uint8_t enhanced_beacon, zb_uint8_t mac_interface)
{
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);
  zb_nlme_join_confirm_t *cnf;

  ZVUNUSED(channel_page);
  ZVUNUSED(enhanced_beacon);
  ZVUNUSED(mac_interface);

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_nlme_join_response", (FMT__0));

  ZB_ASSERT(buf != ZB_BUF_INVALID);

  cnf = ZB_BUF_GET_PARAM(buf, zb_nlme_join_confirm_t);
  cnf->status = status;
  cnf->active_channel = logical_channel;
  cnf->network_address = short_addr;
  /* TODO: recheck if we need channel page in zb_nlme_join_confirm */

  ZB_EXTPANID_COPY(cnf->extended_pan_id, extended_pan_id);

  if (cnf->status == RET_OK)
  {
    ncp_host_state_set_current_page(channel_page);
    ncp_host_state_set_current_channel(cnf->active_channel);
    ncp_host_state_set_short_address(cnf->network_address);
    ncp_host_state_set_extended_pan_id(cnf->extended_pan_id);
    ncp_host_state_set_joined(ZB_TRUE);
    ncp_host_state_set_authenticated(ZB_TRUE);
    if (zb_zdo_tclk_valid() == ZB_FALSE)
    {
      ncp_host_state_set_waiting_for_tclk(ZB_TRUE);
    }
    else
    {
      ncp_host_state_set_waiting_for_tclk(ZB_FALSE);
    }
    zb_buf_set_status(buf, RET_OK);

    zdo_reset_scanlist(ZB_TRUE);

    /* There was direct `zdo_commissioning_start_router_confirm` for routers,
        but `zb_nlme_start_router_req` haven't been called on soc side in such case.
       Unify it with current commissioning type.
       In bdb, this request will be called now. */
      zdo_commissioning_handle_dev_annce_sent_event(buf);
    }
  else if (cnf->status == ERROR_CODE(ERROR_CATEGORY_ZDO, ZB_ZDP_STATUS_NOT_AUTHORIZED))
  {
    zdo_commissioning_authentication_failed(buf);
  }
  else if (cnf->status == ERROR_CODE(ERROR_CATEGORY_ZDO, ZB_ZDP_STATUS_DEV_ANNCE_SENDING_FAILED))
  {
    /* Rejoin current PAN */
    zb_uint8_t *rejoin_reason = ZB_BUF_GET_PARAM(buf, zb_uint8_t);

    ncp_host_state_set_current_page(channel_page);
    ncp_host_state_set_current_channel(cnf->active_channel);
    ncp_host_state_set_short_address(cnf->network_address);
    ncp_host_state_set_extended_pan_id(cnf->extended_pan_id);
    ncp_host_state_set_joined(ZB_TRUE);
    ncp_host_state_set_authenticated(ZB_TRUE);

    /* Set reason here to not corrupt buf */
    *rejoin_reason = ZB_REJOIN_REASON_DEV_ANNCE_SENDING_FAILED;

    zdo_commissioning_initiate_rejoin(buf);
  }
  else
  {
    zdo_commissioning_join_failed(buf);
  }

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_nlme_join_response", (FMT__0));
}
#endif

void ncp_host_handle_nwk_permit_joining_response(zb_ret_t status)
{
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_permit_joining_response", (FMT__0));

  ZB_ASSERT(buf != ZB_BUF_INVALID);

  zb_buf_set_status(buf, status);

  /* We should not use NWK Permit Joining Request from the NCP Host */
  ZB_ASSERT(0);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_permit_joining_response", (FMT__0));
}


#ifdef ZB_ROUTER_ROLE
void ncp_host_handle_nwk_nlme_router_start_response(zb_ret_t status)
{
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_nlme_router_start_response", (FMT__0));

  ZB_ASSERT(buf != ZB_BUF_INVALID);

  if (status == RET_OK)
  {
    ncp_host_state_set_joined(ZB_TRUE);

    zdo_commissioning_start_router_confirm(buf);
  }
  else
  {
    TRACE_MSG(TRACE_ERROR, "failed to start router, status: 0x%x", (FMT__D, status));
    ZB_ASSERT(0);
  }

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_nlme_router_start_response", (FMT__0));
}
#endif /* ZB_ROUTER_ROLE */


#ifdef ZB_JOIN_CLIENT
/* SoC sends this indication when it finishes rejoin */
void ncp_host_handle_nwk_joined_indication(zb_uint16_t nwk_addr, zb_ext_pan_id_t ext_pan_id,
                                           zb_uint8_t channel_page, zb_uint8_t channel,
                                           zb_uint8_t beacon_type, zb_uint8_t mac_interface)
{
  zb_ret_t status;
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);

  ZVUNUSED(beacon_type);
  ZVUNUSED(mac_interface);

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_joined_indication", (FMT__0));

  ZB_ASSERT(buf != ZB_BUF_INVALID);

  zb_buf_set_status(buf, RET_OK);

  ncp_host_state_set_current_page(channel_page);
  ncp_host_state_set_current_channel(channel);
  ncp_host_state_set_short_address(nwk_addr);
  ncp_host_state_set_extended_pan_id(ext_pan_id);
  ncp_host_state_set_joined(ZB_TRUE);
  ncp_host_state_set_authenticated(ZB_TRUE);
  ncp_host_state_set_waiting_for_tclk(ZB_FALSE);

  zdo_reset_scanlist(ZB_TRUE);

  zb_buf_set_status(buf, RET_OK);

#ifdef ZB_ROUTER_ROLE
  if (ncp_host_state_get_device_type() == ZB_NWK_DEVICE_TYPE_ROUTER)
  {
    zdo_commissioning_start_router_confirm(buf);
  }
  else
#endif
  {
    zdo_commissioning_handle_dev_annce_sent_event(buf);
  }

  /* Parent address could change after rejoin, so request it again */
  status = ncp_host_get_parent_address();
  ZB_ASSERT(status == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_joined_indication", (FMT__0));
}

/* SoC sends this indication when it fails to rejoin */
void ncp_host_handle_nwk_join_failed_indication(zb_uint8_t status_category, zb_uint8_t status_code)
{
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);
  zb_ret_t status = ERROR_CODE(status_category, status_code);

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_join_failed_indication", (FMT__0));

  ZB_ASSERT(buf != ZB_BUF_INVALID);

  zb_buf_set_status(buf, status);

  if (status == ERROR_CODE(ERROR_CATEGORY_ZDO, ZB_ZDP_STATUS_NOT_AUTHORIZED))
  {
    zdo_commissioning_authentication_failed(buf);
  }
  else if (status == ERROR_CODE(ERROR_CATEGORY_ZDO, ZB_ZDP_STATUS_DEV_ANNCE_SENDING_FAILED))
  {
    /* Rejoin current PAN */
    zb_uint8_t *rejoin_reason = ZB_BUF_GET_PARAM(buf, zb_uint8_t);
    *rejoin_reason = ZB_REJOIN_REASON_DEV_ANNCE_SENDING_FAILED;

    zdo_commissioning_initiate_rejoin(buf);
  }
  else
  {
    zdo_commissioning_join_failed(buf);
  }

  /* If rejoining has failed, set parent address as unknown */
  ncp_host_state_set_parent_short_address(ZB_UNKNOWN_SHORT_ADDR);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_join_failed_indication", (FMT__0));
}
#endif /* ZB_JOIN_CLIENT */


/* SoC sends this indication when children device leaves the network */
void ncp_host_handle_nwk_leave_indication(zb_ieee_addr_t device_addr, zb_uint16_t short_addr, zb_uint8_t rejoin)
{
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);
  zb_ieee_addr_t own_address;

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_leave_indication", (FMT__0));

  ZB_ASSERT(buf != ZB_BUF_INVALID);

  zb_get_long_address(own_address);

  zb_buf_set_status(buf, RET_OK);

#ifndef ZB_COORDINATOR_ONLY
  if (ZB_IEEE_ADDR_CMP(device_addr, own_address))
  {
    if (!rejoin)
    {
      zb_ext_pan_id_t ext_pan_id;
      ZB_EXTPANID_ZERO(ext_pan_id);

      /* TODO: consider resetting other host state fields or moving this code into function
      * like ncp_host_state_reset */

      ncp_host_state_set_joined(ZB_FALSE);
      ncp_host_state_set_authenticated(ZB_FALSE);
      ncp_host_state_set_tclk_valid(ZB_FALSE);
      ncp_host_state_set_extended_pan_id(ext_pan_id);

      zb_buf_get_out_delayed(zdo_commissioning_leave_done);
    }
    else
    {
      /* NOTE: in case of leave with rejoin the host will wait rejoin status indication */
      zb_buf_get_out_delayed(zdo_commissioning_leave_with_rejoin);
    }
  }
  else
#endif
  {
    zb_zdo_signal_leave_indication_params_t *leave_ind_params = ZB_BUF_GET_PARAM(buf, zb_zdo_signal_leave_indication_params_t);

    ZB_IEEE_ADDR_COPY(leave_ind_params->device_addr, device_addr);
    leave_ind_params->rejoin = rejoin;
    leave_ind_params->short_addr = short_addr;

    zb_send_leave_indication_signal(buf);
  }

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_leave_indication", (FMT__0));
}


#ifdef DEBUG
void ncp_host_handle_debug_tclk_ready_ind(zb_ieee_addr_t ieee_addr)
{
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_debug_tclk_ready_ind", (FMT__0));

  ZB_VERIFY(buf != ZB_BUF_INVALID, RET_NO_MEMORY);

  zb_send_tclk_ready_debug_signal(buf, ieee_addr);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_debug_tclk_ready_ind", (FMT__0));
}
#endif

/* Can't use `zb_send_device_ready_for_interview_signal_delayed` because we do not have the addr_ref
 * Only short and ieee address, so we send the signal directly
 */
static void ncp_host_handle_device_interview_common(zb_ieee_addr_t ieee_addr, zb_uint16_t short_addr, zb_ret_t status, zb_uint32_t signal_code)
{
  zb_zdo_signal_device_ready_for_interview_params_t *interview_params;
  zb_bufid_t buf;

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_device_interview_common %d %d", (FMT__D_D, signal_code, status));

  buf = zb_buf_get(ZB_TRUE, 0);
  ZB_VERIFY(buf != ZB_BUF_INVALID, RET_NO_MEMORY);

  interview_params = (zb_zdo_signal_device_ready_for_interview_params_t*)zb_app_signal_pack(
    buf, signal_code, (zb_int16_t)status, (zb_uint8_t)sizeof(*interview_params));

  ZB_IEEE_ADDR_COPY(interview_params->long_addr, ieee_addr);
  interview_params->short_addr = short_addr;

  ZB_SCHEDULE_CALLBACK(zb_signal_dispatch, buf);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_device_interview_common", (FMT__0));
}

void ncp_host_handle_device_ready_for_interview(zb_ieee_addr_t ieee_addr, zb_uint16_t short_addr)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_device_ready_for_interview", (FMT__0));
  ncp_host_handle_device_interview_common(ieee_addr, short_addr, RET_OK, ZB_ZDO_SIGNAL_DEVICE_READY_FOR_INTERVIEW);
  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_device_ready_for_interview", (FMT__0));
}

void ncp_host_handle_device_interview_finished(zb_ieee_addr_t ieee_addr, zb_uint16_t short_addr, zb_ret_t status)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_device_interview_finished", (FMT__0));
  ncp_host_handle_device_interview_common(ieee_addr, short_addr, status, ZB_ZDO_SIGNAL_DEVICE_INTERVIEW_FINISHED);
  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_device_interview_finished", (FMT__0));
}

void ncp_host_handle_nwk_address_update_indication(zb_uint16_t nwk_addr)
{
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);

  ZVUNUSED(nwk_addr);

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_address_update_indication", (FMT__0));

  ZB_ASSERT(buf != ZB_BUF_INVALID);

  ncp_host_state_set_short_address(nwk_addr);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_address_update_indication", (FMT__0));
}


void ncp_host_handle_nwk_pan_id_conflict_indication(void)
{
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_pan_id_conflict_indication", (FMT__0));

  ZB_ASSERT(buf != ZB_BUF_INVALID);

  TRACE_MSG(TRACE_NWK3, "Sending a ZB_NWK_SIGNAL_PANID_CONFLICT_DETECTED signal", (FMT__0));
  zb_app_signal_pack_with_data(buf, ZB_NWK_SIGNAL_PANID_CONFLICT_DETECTED, RET_OK);
  ZB_SCHEDULE_CALLBACK(zb_signal_dispatch, buf);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_pan_id_conflict_indication", (FMT__0));
}


#ifdef ZB_JOIN_CLIENT
void ncp_host_handle_nwk_parent_lost_indication(void)
{
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);
  zb_uint8_t *rejoin_reason;

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_parent_lost_indication", (FMT__0));

  ZB_ASSERT(buf != ZB_BUF_INVALID);

  rejoin_reason = ZB_BUF_GET_PARAM(buf, zb_uint8_t);

  *rejoin_reason = ZB_REJOIN_REASON_PARENT_LOST;
  ZB_SCHEDULE_CALLBACK(zdo_commissioning_initiate_rejoin, buf);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_parent_lost_indication", (FMT__0));
}
#endif


#ifdef ZB_APSDE_REQ_ROUTING_FEATURES
void ncp_host_handle_nwk_route_request_send_indication(zb_uint16_t nwk_addr)
{
  /* TODO: fill host_ctx.soc_state with new values */
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);

  ZVUNUSED(nwk_addr);

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_route_request_send_indication", (FMT__0));

  ZB_ASSERT(buf != ZB_BUF_INVALID);

  /* TODO: Implement adapter logic, if it is needed */

  ncp_host_handle_nwk_route_request_send_indication_adapter(buf);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_route_request_send_indication", (FMT__0));
}

void ncp_host_handle_nwk_route_reply_indication(zb_uint16_t nwk_addr)
{
  /* TODO: fill host_ctx.soc_state with new values */
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);

  ZVUNUSED(nwk_addr);

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_route_reply_indication", (FMT__0));

  ZB_ASSERT(buf != ZB_BUF_INVALID);

  /* TODO: Implement adapter logic, if it is needed */

  ncp_host_handle_nwk_route_reply_indication_adapter(buf);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_route_reply_indication", (FMT__0));
}

void ncp_host_handle_nwk_route_record_send_indication(zb_uint16_t nwk_addr)
{
  /* TODO: fill host_ctx.soc_state with new values */
  zb_bufid_t buf = zb_buf_get(ZB_TRUE, 0);

  ZVUNUSED(nwk_addr);

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_route_record_send_indication", (FMT__0));

  ZB_ASSERT(buf != ZB_BUF_INVALID);

  /* TODO: Implement adapter logic, if it is needed */

  ncp_host_handle_nwk_route_record_indication_adapter(buf);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_route_record_send_indication", (FMT__0));
}
#endif

void ncp_host_handle_nwk_set_fast_poll_interval_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_set_fast_poll_interval_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_set_fast_poll_interval_response", (FMT__0));
}


void ncp_host_handle_nwk_set_long_poll_interval_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_set_long_poll_interval_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_set_long_poll_interval_response", (FMT__0));
}


void ncp_host_handle_nwk_start_fast_poll_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_start_fast_poll_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_start_fast_poll_response", (FMT__0));
}


void ncp_host_handle_nwk_start_turbo_poll_packets_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_start_turbo_poll_packets_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_start_turbo_poll_packets_response", (FMT__0));
}


void ncp_host_handle_nwk_turbo_poll_cancel_packet_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_turbo_poll_cancel_packet_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_turbo_poll_cancel_packet_response", (FMT__0));
}


void ncp_host_handle_nwk_start_turbo_poll_continuous_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_start_turbo_poll_continuous_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_start_turbo_poll_continuous_response", (FMT__0));
}


void ncp_host_handle_nwk_permit_turbo_poll_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_permit_turbo_poll_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_permit_turbo_poll_response", (FMT__0));
}


void ncp_host_handle_nwk_set_fast_poll_timeout_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_set_fast_poll_timeout_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_set_fast_poll_timeout_response", (FMT__0));
}



void ncp_host_handle_nwk_start_poll_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_start_poll_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_start_poll_response", (FMT__0));
}


void ncp_host_handle_nwk_stop_poll_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_stop_poll_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_stop_poll_response", (FMT__0));
}


void ncp_host_handle_nwk_enable_turbo_poll_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_enable_turbo_poll_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_enable_turbo_poll_response", (FMT__0));
}


void ncp_host_handle_nwk_disable_turbo_poll_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_disable_turbo_poll_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_disable_turbo_poll_response", (FMT__0));
}


void ncp_host_handle_nwk_turbo_poll_continuous_leave_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_turbo_poll_continuous_leave_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_turbo_poll_continuous_leave_response", (FMT__0));
}


void ncp_host_handle_nwk_turbo_poll_packets_leave_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_turbo_poll_packets_leave_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_turbo_poll_packets_leave_response", (FMT__0));
}


void ncp_host_handle_nwk_start_concentrator_mode_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_start_concentrator_mode_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_start_concentrator_mode_response", (FMT__0));
}


void ncp_host_handle_nwk_stop_concentrator_mode_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_stop_concentrator_mode_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_stop_concentrator_mode_response", (FMT__0));
}


void ncp_host_handle_nwk_start_pan_id_conflict_resolution_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_start_pan_id_conflict_resolution_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_start_pan_id_conflict_resolution_response", (FMT__0));
}


void ncp_host_handle_nwk_enable_pan_id_conflict_resolution_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_enable_pan_id_conflict_resolution_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_enable_pan_id_conflict_resolution_response", (FMT__0));
}


void ncp_host_handle_nwk_enable_auto_pan_id_conflict_resolution_response(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_enable_auto_pan_id_conflict_resolution_response, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code == RET_OK);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_enable_auto_pan_id_conflict_resolution_response", (FMT__0));
}


void ncp_host_handle_nwk_get_nbr_iterator_next_response(zb_ret_t status,
                                                        zb_uint16_t index,
                                                        zb_uint32_t update_count,
                                                        zb_nwk_nbr_iterator_entry_t *nbt_entry)
{
  zb_nwk_nbr_iterator_entry_t *ret_nbt;
  zb_nwk_nbr_iterator_params_t *ret_params;

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_nwk_get_nbr_iterator_next_response", (FMT__0));

  if (g_adapter_ctx.nbr_iterator.cb != NULL)
  {
    zb_buf_set_status(g_adapter_ctx.nbr_iterator.buf, status);
  }
  else
  {
    status = RET_INVALID_STATE;
  }

  if (status == RET_OK)
  {
    ret_nbt = (zb_nwk_nbr_iterator_entry_t*)zb_buf_initial_alloc(g_adapter_ctx.nbr_iterator.buf, sizeof(zb_nwk_nbr_iterator_entry_t));
    ret_params = ZB_BUF_GET_PARAM(g_adapter_ctx.nbr_iterator.buf, zb_nwk_nbr_iterator_params_t);

    ret_params->update_count = update_count;
    ret_params->index = index;
    if (ret_params->index != ZB_NWK_NBR_ITERATOR_INDEX_EOT)
    {
      *ret_nbt = *nbt_entry;
    }
  }

  if (g_adapter_ctx.nbr_iterator.cb)
  {
    zb_callback_t user_cb = g_adapter_ctx.nbr_iterator.cb;
    g_adapter_ctx.nbr_iterator.cb = NULL;
    user_cb(g_adapter_ctx.nbr_iterator.buf);
  }

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_nwk_get_nbr_iterator_next_response", (FMT__0));
}

void ncp_host_handle_prepare_nwk_channel_pan_id_change_response(zb_ret_t status, zb_uint16_t error_cnt)
{
  zb_callback_t user_cb = g_adapter_ctx.panid_change_ctx_cb;
  zb_channel_panid_change_preparation_t *params;
  zb_bufid_t buf;

  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_prepare_nwk_channel_pan_id_change_response %d", (FMT__D, status));

  ZB_ASSERT(status != RET_INVALID_FORMAT);
  ZB_ASSERT(user_cb != NULL);

  buf = zb_buf_get(ZB_TRUE, 0);
  params = ZB_BUF_GET_PARAM(buf, zb_channel_panid_change_preparation_t);

  ZB_VERIFY(buf != ZB_BUF_INVALID, RET_NO_MEMORY);

  params->error_cnt = error_cnt;

  g_adapter_ctx.panid_change_ctx_cb = NULL;
  user_cb(buf);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_prepare_nwk_channel_pan_id_change_response", (FMT__0));
}

void ncp_host_handle_zb_start_channel_change(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_zb_start_channel_change, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code != RET_INVALID_FORMAT);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_zb_start_channel_change", (FMT__0));
}

void ncp_host_handle_zb_start_pan_id_change(zb_ret_t status_code)
{
  TRACE_MSG(TRACE_TRANSPORT3, ">> ncp_host_handle_zb_start_pan_id_change, status_code %d",
    (FMT__D, status_code));

  ZB_ASSERT(status_code != RET_INVALID_FORMAT);

  TRACE_MSG(TRACE_TRANSPORT3, "<< ncp_host_handle_zb_start_pan_id_change", (FMT__0));
}
