/*
 * ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2023 DSR Corporation, Denver CO, USA.
 * http://www.dsr-zboss.com
 * http://www.dsr-corporation.com
 * All rights reserved.
 *
 *
 * Use in source and binary forms, redistribution in binary form only, with
 * or without modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 2. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 3. This software must only be used in or with a processor manufactured by Nordic
 *    Semiconductor ASA, or in or with a processor manufactured by a third party that
 *    is used in combination with a processor manufactured by Nordic Semiconductor.
 *
 * 4. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*  PURPOSE: NCP traffic dump.
*/

#define ZB_TRACE_FILE_ID 61

/* If compiling not inside ZBOSS codebase (even reduced), we have no zb_vendor.h */
#ifdef ZBNCP_COMPILE_INSIDE_ZBOSS

#include "zb_vendor.h"

#if defined ZBNCP_USE_ZBOSS_DUMP

#include "low_level/zbncp_dump.h"

#if defined ZB_TRAFFIC_DUMP_ON
#include "zb_common.h"
#include "zb_mac_transport.h"
#include "ncp_hl_proto.h"

void zb_dump_put_bytes(const zb_uint8_t *buf, zb_short_t len);

/**
   Dump traffic from NCP.

   Dump file format produce: zb_mac_transport_hdr_t and zbncp_dump_hdr_t
   before packet.

   @param pkt_buff    - pointer to pkt to dump.
   @param is_w   - if 1, this is output, else input

   @return nothing.
*/
void zbncp_traffic_dump(const zbncp_ll_pkt_t *pkt_buff, zb_bool_t is_w)
{
  if(ZB_U2B(g_traf_dump))
  {
    if(pkt_buff->hdr.type == ZBNCP_LL_TYPE_DUMP)
    {
      /* Dump into file traffic at Host only. Device has its own dump directly from MAC */
#ifdef NCP_MODE_HOST
      /* traffic dump */
      zb_uint8_t *p = (zb_uint8_t*)pkt_buff->body.data + sizeof(ncp_hl_ind_header_t);
      zb_uint_t data_len = pkt_buff->hdr.len - (ZBNCP_LL_HDR_SIZE + ZBNCP_LL_BODY_CRC_SIZE + sizeof(ncp_hl_ind_header_t) + 1 + 4);
      zb_uint8_t is_w;
      zb_time_t t;
      zb_uint16_t t16;
      zb_mac_transport_hdr_t h;

      /* Decode parameters of NCP_HL_TRACE_IND */
      is_w = *p++;
      ZB_LETOH32(&t, p);
      t16 = (zb_uint16_t)t;
      p += sizeof(t);

      /* Put data into dump file in ZBOSS trffic dump format. Data already has
       * dump header filled by mac_traffic_dump_put */
      h.len = sizeof(h) + data_len;
      h.type = (ZB_MAC_TRANSPORT_TYPE_DUMP | (is_w ? 0x80U : 0U));
      h.time = t16;
      zb_dump_put_bytes((const zb_uint8_t*)&h, (zb_short_t)4);
      zb_dump_put_bytes(p, data_len);
#endif
    }
    else
    {
      /* include body CRC to hdr to make it little-endian */
      zb_uint8_t dump_hdr[sizeof(zbncp_ll_pkt_wo_body_t) + ZBNCP_LL_SIGN_SIZE];
      zbncp_ll_pkt_wo_body_t *dump_hdr_struct = (zbncp_ll_pkt_wo_body_t *)dump_hdr;

#ifdef NCP_MODE_HOST
      /* Traffic dump is initially designed to be run on dev, so need to revert the direction */
      is_w = !is_w;
#endif
      dump_hdr[0] = ZBNCP_LL_SIGN_FIRST_BYTE;                                 // Little-endian signature
      dump_hdr[1] = ZBNCP_LL_SIGN_SECOND_BYTE;

      ZB_HTOLE16(dump_hdr + 2, &pkt_buff->hdr.len);
      ZB_MEMCPY((zb_uint8_t *)&dump_hdr_struct->hdr.type, (zb_uint8_t *)&pkt_buff->hdr.type, 3);

      if(pkt_buff->hdr.len == ZBNCP_LL_HDR_SIZE)
      { //pkt hasn't body, then dump without body crc
        zb_dump_put_2buf(dump_hdr, sizeof(dump_hdr) - ZBNCP_LL_BODY_CRC_SIZE, NULL, 0, ZBNCP_TRANSPORT_TYPE_DUMP, is_w);
      }
      else
      {
        ZB_HTOLE16(dump_hdr + ZBNCP_LL_BODY_CRC_OFFSET, &pkt_buff->body.crc);
        zb_dump_put_2buf(dump_hdr, sizeof(dump_hdr),
                         pkt_buff->body.data, pkt_buff->hdr.len - (ZBNCP_LL_HDR_SIZE + ZBNCP_LL_BODY_CRC_SIZE), // body size without crc
                         ZBNCP_TRANSPORT_TYPE_DUMP, is_w);
      }
    }
  }
}

#endif /* defined ZB_TRAFFIC_DUMP_ON && !defined NCP_MODE_HOST */

#endif /* ZBNCP_USE_ZBOSS_DUMP */

#endif  /* ZBNCP_COMPILE_INSIDE_ZBOSS */
