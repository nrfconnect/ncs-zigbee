/*
 * ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2023 DSR Corporation, Denver CO, USA.
 * http://www.dsr-zboss.com
 * http://www.dsr-corporation.com
 * All rights reserved.
 *
 *
 * Use in source and binary forms, redistribution in binary form only, with
 * or without modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 2. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 3. This software must only be used in or with a processor manufactured by Nordic
 *    Semiconductor ASA, or in or with a processor manufactured by a third party that
 *    is used in combination with a processor manufactured by Nordic Semiconductor.
 *
 * 4. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/* PURPOSE: GPIO Serve API
*/

#define ZB_TRACE_FILE_ID 30210

#include "zb_common.h"

#include <fcntl.h>
#include <errno.h>

#include <sys/ioctl.h>
#include <sys/file.h>
#include <linux/spi/spidev.h>
#include <stdio.h>
#include <unistd.h>


static zb_ret_t zb_gpio_open(zb_gpio_conf_t *conf)
{
  zb_ret_t ret = RET_OK;

  char s[ZB_GPIO_MAX_FD_PATH_LEN + 8];

  /* Standard Linux name like /sys/class/gpio/gpio/gpio25 */
  if (strlen(conf->path) > ZB_GPIO_MAX_FD_PATH_LEN)
  {
    ret = RET_ERROR;
  }
  else
  {
    strcpy(s, conf->path);

    if (strstr(conf->path, "/sys/class/gpio/gpio"))
    {
      strcat(s, "/value");
    }
  }

  if (ret == RET_OK)
  {
    conf->fd = open(s, (conf->direction == ZB_GPIO_DIR_IN ? O_RDONLY : O_WRONLY));

    if (conf->fd < 0)
    {
      TRACE_MSG(TRACE_ERROR, "failed to open gpio: %s, errno: %d", (FMT__P_D, conf->path, errno));
      ret = SYSTEM_ERROR_CODE(errno);
    }
  }
  return ret;
}

static void zb_gpio_close(zb_gpio_conf_t *conf)
{
  if (conf->fd >= 0)
  {
    close(conf->fd);
    conf->fd = -1;
  }
}

static zb_ret_t zb_gpio_init(zb_gpio_conf_t *conf, const char *path,
                             zb_gpio_direction_t direction, zb_gpio_edge_t edge)
{
  zb_ret_t ret = RET_OK;

  ZB_ASSERT(path != NULL);

  strncpy(conf->path, path, ZB_GPIO_MAX_FD_PATH_LEN - 1);
  conf->path[ZB_GPIO_MAX_FD_PATH_LEN - 1] = '\0';
  conf->direction = direction;
  conf->edge = edge;

  if (strstr(conf->path, "/sys/class/gpio/gpio"))
  {
    ret = zb_gpio_setup(conf);
  }
  if (ret == RET_OK)
  {
    ret = zb_gpio_open(conf);
  }

  return ret;
}

zb_ret_t zb_gpio_in_init(zb_gpio_conf_t *conf, const char *path, zb_gpio_edge_t edge)
{
  zb_ret_t ret;

  TRACE_MSG(TRACE_COMMON1, ">zb_gpio_in_init path: %s", (FMT__P, path));

  ret = zb_gpio_init(conf, path, ZB_GPIO_DIR_IN, edge);

  TRACE_MSG(TRACE_COMMON1, "<zb_gpio_in_init %d", (FMT__D, ret));
  return ret;
}

zb_ret_t zb_gpio_out_init(zb_gpio_conf_t *conf, const char *path)
{
  zb_ret_t ret;

  TRACE_MSG(TRACE_COMMON1, ">zb_gpio_out_init path: %s", (FMT__P, path));

  ret = zb_gpio_init(conf, path, ZB_GPIO_DIR_OUT, ZB_GPIO_EDGE_NONE);

  TRACE_MSG(TRACE_COMMON1, "<zb_gpio_out_init %d", (FMT__D, ret));
  return ret;
}

void zb_gpio_deinit(zb_gpio_conf_t *conf)
{
  TRACE_MSG(TRACE_COMMON1, ">zb_gpio_deinit path: %s", (FMT__P, conf->path));
  zb_gpio_close(conf);
  TRACE_MSG(TRACE_COMMON1, "<zb_gpio_deinit", (FMT__0));
}

zb_ret_t zb_gpio_setup(zb_gpio_conf_t *conf)
{
  zb_ret_t ret = RET_OK;
  char s[ZB_GPIO_MAX_FD_PATH_LEN];
  FILE *f = NULL;

  TRACE_MSG(TRACE_COMMON1, ">zb_gpio_setup path: %s", (FMT__P, conf->path));

  if (strlen(conf->path) > ZB_GPIO_MAX_FD_PATH_LEN + 11)
  {
    ret = RET_ERROR;
  }
  else
  {
    strcpy(s, conf->path);
    strcat(s, "/direction");
  }

  if (ret == RET_OK)
  {
    f = fopen(s, "w+");

    if (f)
    {
      fprintf(f, "%s\n", (conf->direction == ZB_GPIO_DIR_IN ? "in" : "out"));
      fclose(f);
      ret = RET_OK;
    }
    else
    {
      TRACE_MSG(TRACE_ERROR, "failed to open %s (w+)", (FMT__P, s));
      ret = SYSTEM_ERROR_CODE(errno);
    }
  }

  if (f && conf->direction == ZB_GPIO_DIR_IN && conf->edge != ZB_GPIO_EDGE_NONE)
  {
    /* configure interrupts */

    /* Size has been checked already */
    strcpy(s, conf->path);
    strcat(s, "/edge");

    f = fopen(s, "w+");

    if (f)
    {
      const char *edge_type;

      switch (conf->edge)
      {
        case ZB_GPIO_EDGE_RISING:
          edge_type = "rising\n";
          break;
        case ZB_GPIO_EDGE_FALLING:
          edge_type = "falling\n";
          break;
        case ZB_GPIO_EDGE_BOTH:
          edge_type = "both\n";
          break;
        default:
          ZB_ASSERT(0);
          break;
      }
      fprintf(f, "%s", edge_type);
      fclose(f);
    }
    else
    {
      TRACE_MSG(TRACE_ERROR, "failed to open %s (w+)", (FMT__P, s));
      ret = SYSTEM_ERROR_CODE(errno);
    }
  }

  TRACE_MSG(TRACE_COMMON1, "<zb_gpio_setup %d", (FMT__D, ret));
  return ret;
}

zb_ret_t zb_gpio_on_off(zb_gpio_conf_t *conf, zb_bool_t state)
{
  zb_ret_t ret;

  TRACE_MSG(TRACE_COMMON1, ">zb_gpio_on_off path: %s, state: %hd", (FMT__P_H, conf->path, state));

  ZB_ASSERT(conf->fd);

  do
  {
    if (write(conf->fd, (state ? "1\n" : "0\n"), 2) < 0)
    {
      TRACE_MSG(TRACE_ERROR, "Failed to write gpio path %s errno: %d", (FMT__P_D, conf->path, errno));
      ret = SYSTEM_ERROR_CODE(errno);
      break;
    }
    ret = RET_OK;
  } while (0);

  TRACE_MSG(TRACE_COMMON1, "<zb_gpio_on_off %d", (FMT__D, ret));
  return ret;
}


zb_ret_t zb_gpio_read(zb_gpio_conf_t *conf)
{
  zb_ret_t ret = 0;
  char val = '1';

  lseek(conf->fd, 0, SEEK_SET);
  ret = read(conf->fd, &val, sizeof(val));

  if (ret)
  {
    ret = val - '0';
  }
  /* Handle zero bytes as a separate state because errno, possibly, will be equal to 0.
     Return EOF in such case. */
  else if (ret == 0)
  {
    ret = RET_EOF;
  }
  else
  {
    ret = SYSTEM_ERROR_CODE(errno);
  }

  return ret;
}


/* mainly copy-paste from ncp/transport/rpi_spidev/linux_spi/linux_spi_transport_juna.c */

osif_ipc_handle_t zb_spi_init(const char *path, zb_uint8_t mode, zb_uint32_t speed, zb_bool_t no_cs)
{
  int32_t spi_dev_fd = -1;
  int32_t ret = 0;
  uint8_t bits = 8;

  spi_dev_fd = open(path, O_RDWR);
  do
  {
    if (spi_dev_fd < 0)
    {
      TRACE_MSG(TRACE_ERROR, "can't open spi device %d", (FMT__D, errno));
      ret = -1;
      break;
    }

    /********************SPIDEV CONFIGURATION******************/
    if (no_cs)
    {
#ifndef __ANDROID__  // ioctl(SPI_IOC_WR_MODE) fails on Android when SPI_NO_CS is set
    /* We want to set CS manually, via GPIO line */
      mode |= SPI_NO_CS;
#endif
    }

    ret = ioctl(spi_dev_fd, SPI_IOC_WR_MODE, &mode);
    if (-1 == ret)
    {
      TRACE_MSG(TRACE_ERROR, "can't set spi mode %d", (FMT__D, errno));
      break;
    }
    ret = ioctl(spi_dev_fd, SPI_IOC_RD_MODE, &mode);
    if (-1 == ret)
    {
      TRACE_MSG(TRACE_ERROR, "can't set spi mode %d", (FMT__D, errno));
      break;
    }

    ret = ioctl(spi_dev_fd, SPI_IOC_WR_BITS_PER_WORD, &bits);
    if (-1 == ret)
    {
      TRACE_MSG(TRACE_ERROR, "can't set bits per word %d", (FMT__D, errno));
      break;
    }
    ret = ioctl(spi_dev_fd, SPI_IOC_RD_BITS_PER_WORD, &bits);
    if (-1 == ret)
    {
      TRACE_MSG(TRACE_ERROR, "can't set bits per word %d", (FMT__D, errno));
      break;
    }

    ret = ioctl(spi_dev_fd, SPI_IOC_WR_MAX_SPEED_HZ, &speed);
    if (-1 == ret)
    {
      TRACE_MSG(TRACE_ERROR, "can't set max speed %d", (FMT__D, errno));
      break;
    }
    ret = ioctl(spi_dev_fd, SPI_IOC_RD_MAX_SPEED_HZ, &speed);
    if (-1 == ret)
    {
      TRACE_MSG(TRACE_ERROR, "can't set max speed %d", (FMT__D, errno));
      break;
    }
  } while(ZB_FALSE);
  if (ret < 0)
  {
    if (spi_dev_fd >= 0)
    {
      close(spi_dev_fd);
    }
    ret = SYSTEM_ERROR_CODE(errno);
  }
  else
  {
    ret = spi_dev_fd;
  }
  return ret;
}


zb_ret_t zb_spi_transfer(osif_ipc_handle_t fd, const uint8_t *tx_buf, size_t tx_len,
                         const uint8_t *rx_buf, size_t rx_len,
                         zb_uint32_t speed, zb_uint32_t cs_delay)
{
  zb_ret_t ret;
  struct spi_ioc_transfer tr[2] = {0};

  ZB_BZERO(tr, sizeof(tr));

  tr[1].tx_buf = (uintptr_t) tx_buf;
  tr[1].rx_buf = (uintptr_t) rx_buf;
  tr[1].len = (uint32_t)(tx_len != 0u ? tx_len : rx_len);
  tr[1].speed_hz = speed;
  tr[1].bits_per_word = 8;
  /*
    done by bzero
  tr[1].delay_usecs = 0u;
  tr[1].cs_change = 0;
  */

  if (cs_delay == 0u)
  {
    ret = ioctl(fd, SPI_IOC_MESSAGE(1), &tr[1]);
  }
  else
  {
    /* Built-in CS. Use 2 transfers to implement a CS delay */
    /*
      done by bzero
    tr[0].tx_buf = (uintptr_t)0;
    tr[0].rx_buf = (uintptr_t)0;
    tr[0].len = 0u;
    tr[0].cs_change = 0;
    */
    /* First transfer in transaction is CS on, then delay */
    tr[0].delay_usecs = (uint32_t)cs_delay;
    tr[0].speed_hz = speed;
    tr[0].bits_per_word = 8;
    ret = ioctl(fd, SPI_IOC_MESSAGE(2), &tr[0]);
  }
  if (ret < 0)
  {
    TRACE_MSG(TRACE_ERROR, "spi_transfer: ioctl error %d", (FMT__D, errno));
    ret = SYSTEM_ERROR_CODE(errno);
  }
  else
  {
    ret = RET_OK;
  }

  return ret;
}
