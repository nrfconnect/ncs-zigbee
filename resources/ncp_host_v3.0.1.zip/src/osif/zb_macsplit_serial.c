/*
 * ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2022 DSR Corporation, Denver CO, USA.
 * http://www.dsr-zboss.com
 * http://www.dsr-corporation.com
 * All rights reserved.
 *
 *
 * Use in source and binary forms, redistribution in binary form only, with
 * or without modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 2. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 3. This software must only be used in or with a processor manufactured by Nordic
 *    Semiconductor ASA, or in or with a processor manufactured by a third party that
 *    is used in combination with a processor manufactured by Nordic Semiconductor.
 *
 * 4. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/*
PURPOSE: Linux UART API for the split MAC implementations
*/

#define ZB_TRACE_FILE_ID 30020

#include "zb_common.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <poll.h>
#include <unistd.h>
#include <errno.h>
#include <termios.h>
#include <stdio.h>

#if defined(ZB_TRANSPORT_LINUX_UART)

#include "zb_macsplit_transport_linux.h"

#ifndef ZB_MAC_TRANSPORT_UART_SPEED
#define ZB_MAC_TRANSPORT_UART_SPEED 115200UL
#endif

#ifndef ZB_MAC_TRANSPORT_UART_PATH_SIZE
#define ZB_MAC_TRANSPORT_UART_PATH_SIZE 256
#endif

/*
That code has interface of zb_macsplit_transport_linux_uart.c from linux embedded platform repo,
but its implementation uses routines from zb_osif_serial.c and zb_osif_serial_common.c
initially made for NCP.
*/

static zb_serial_port_t g_macsplit_port = SERIAL_PORT_INVALID;


/**
 * Provide UART port path
 */
ZB_WEAK_PRE const char* zb_mac_uart_path() ZB_WEAK;

/**
 * @brief Obtain a file name for a macsplit serial port.
 * 
 * Historically, ZBOSS had a lot of ways to define the filename. Now the rule is following:
 * 1) If MACSPLIT_ENV_NAME defined, use it as a variable name and read a file name from there
 * 2) (Legacy) Try to read a "MACSPLIT_TTY" variable, used to set a filename on a host side
 * 3) (Legacy) Try to read a "MACSPLIT_SLAVE_PTY" variable, used to set a filename on a device side
 * 4) Use a default file name if defined by ZB_MACSPLIT_DEFAULT_PATH 
 * 5) Throw an error
 * 
 * @return const char* 
 */
const char* zb_mac_uart_path(void)
{
  char* filename = NULL;

#if defined ZB_MACSPLIT_ENV_NAME
  TRACE_MSG(TRACE_MAC2, "Getting a file name from the environment variable %s", (FMT__P, ZB_MACSPLIT_ENV_NAME));
  filename = getenv(ZB_MACSPLIT_ENV_NAME);
#endif /* defined SERIAL_ENV_NAME */

  /* Legacy step, should be removed in future. */
  if (filename == NULL)
  {
    TRACE_MSG(TRACE_MAC2, "Getting a file name from the environment variable MACSPLIT_TTY", (FMT__0));
    filename = getenv("MACSPLIT_TTY");
  }

  /* Legacy step, should be removed in future. */
  if (filename == NULL)
  {
    TRACE_MSG(TRACE_MAC2, "Getting a file name from the environment variable MACSPLIT_SLAVE_PTY", (FMT__0));
    filename = getenv("MACSPLIT_SLAVE_PTY");
  }

#if defined(ZB_MACSPLIT_DEFAULT_PATH)
  if (filename == NULL)
  {
    TRACE_MSG(TRACE_MAC2, "Using a %s file name defined in the MACSPLIT_DEFAULT_PATH", (FMT__P, ZB_MACSPLIT_DEFAULT_PATH));
    filename = ZB_MACSPLIT_DEFAULT_PATH;
  }
#endif

  ZB_VERIFY(filename != NULL, RET_FILE_NOT_FOUND);

  TRACE_MSG(TRACE_MAC2, "Macsplit serial file name is %s", (FMT__P, filename));
  return filename;
}

#ifdef ZB_MAC_TRANSPORT_UART_USE_RST_LINE
static zb_ret_t zb_mac_uart_open_rst_line()
{
  zb_uint8_t uart_path[ZB_MAC_TRANSPORT_UART_PATH_SIZE];

  ZB_MACSPLIT_IOCTX().uart_rst_fd = -1;
  snprintf((char*)uart_path, ZB_MAC_TRANSPORT_UART_PATH_SIZE, "%s", zb_mac_transport_uart_rst_path_get());
  errno = 0;
  ZB_MACSPLIT_IOCTX().uart_rst_fd = open((const char *)uart_path, O_RDWR);

  if (ZB_MACSPLIT_IOCTX().uart_rst_fd < 0)
  {
    TRACE_MSG(TRACE_ERROR, "Unable to open uart rst line: %d", (FMT__D, errno));
    ZB_ASSERT(0);
  }
  return RET_OK;
}

/* Default implementation */
ZB_WEAK_PRE const zb_char_t* zb_mac_transport_uart_rst_path_get() ZB_WEAK;
const zb_char_t* zb_mac_transport_uart_rst_path_get()
{
  return ZB_MAC_TRANSPORT_UART_RST_PATH;
}

static zb_ret_t zb_mac_uart_close_rst_line()
{
  if (ZB_MACSPLIT_IOCTX().uart_rst_fd != -1)
  {
    close(ZB_MACSPLIT_IOCTX().uart_rst_fd);
    ZB_MACSPLIT_IOCTX().uart_rst_fd = -1;
  }
  return RET_OK;
}

static zb_ret_t zb_mac_uart_rst_radio()
{
  zb_ret_t ret = RET_OK;

  TRACE_MSG(TRACE_INFO1, ">zb_mac_uart_rst_radio %d", (FMT__D, ZB_MACSPLIT_IOCTX().uart_rst_fd));

  ZB_ASSERT(ZB_MACSPLIT_IOCTX().uart_rst_fd);

  do
  {
    /* clear gpio pin */
    if (write(ZB_MACSPLIT_IOCTX().uart_rst_fd, "0", 2) < 0)
    {
      zb_mac_uart_close_rst_line();
      TRACE_MSG(TRACE_ERROR, "Failed to clear reset gpio pin errno: %d", (FMT__D, errno));
      ret = RET_ERROR;
      break;
    }
    lseek(ZB_MACSPLIT_IOCTX().uart_rst_fd, 0, SEEK_SET);
    zb_osif_wait_ms(100);

    /* set gpio pin */
    if (write(ZB_MACSPLIT_IOCTX().uart_rst_fd, "1", 2) < 0)
    {
      zb_mac_uart_close_rst_line();
      TRACE_MSG(TRACE_ERROR, "Failed to set reset gpio pin errno: %d", (FMT__D, errno));
      ret = RET_ERROR;
      break;
    }
    lseek(ZB_MACSPLIT_IOCTX().uart_rst_fd, 0, SEEK_SET);
    zb_osif_wait_ms(100);
  } while (0);

  zb_macsplit_mlme_mark_radio_reset();

  TRACE_MSG(TRACE_INFO1, "<zb_mac_uart_rst_radio %hd", (FMT__H, ret));
  return ret;
}

zb_ret_t zb_linux_turn_off_radio()
{
  TRACE_MSG(TRACE_INFO1, "zb_linux_turn_off_radio %d", (FMT__D, ZB_MACSPLIT_IOCTX().uart_rst_fd));

  if (ZB_MACSPLIT_IOCTX().uart_rst_fd)
  {
    write(ZB_MACSPLIT_IOCTX().uart_rst_fd, "0", 2);
    return RET_OK;
  }
  return RET_ERROR;
}
#endif  /* ZB_MAC_TRANSPORT_UART_USE_RST_LINE */

#ifdef ZB_MACSPLIT_HOST
static void uart_rx_handler(zb_uint8_t b);
#endif /* ZB_MACSPLIT_HOST */

/**
 * Open file, defined by @ref zb_mac_uart_path(),
 * set com port parameters, if fail, invoke ZB_ASSERT(0)
 *
 * @return opened file descriptor
 */
void zb_mac_uart_open(void)
{
  const char* filename = zb_mac_uart_path();

#ifdef ZB_MAC_TRANSPORT_UART_USE_RST_LINE
  zb_mac_uart_open_rst_line();
  zb_mac_uart_rst_radio();
#endif  /* ZB_MAC_TRANSPORT_UART_USE_RST_LINE */

  TRACE_MSG(TRACE_MAC2, "Opening a port %s", (FMT__P, filename));
#if defined ZB_MACSPLIT_HOST
  g_macsplit_port = zb_osif_mserial_open(filename, ZB_MAC_TRANSPORT_UART_SPEED);
#elif defined ZB_MACSPLIT_DEVICE
  g_macsplit_port = zb_osif_mserial_create_pty(filename, ZB_MAC_TRANSPORT_UART_SPEED);
#endif

#if !defined ZB_HAVE_ASYNC_SERIAL
  #ifdef ZB_MACSPLIT_HOST
    zb_osif_mserial_set_byte_received_cb(g_macsplit_port, uart_rx_handler);
  #endif
#else
  #error Not implemented yet!
  /*
TODO: implement logic similar to

  read_data_len = ZB_RING_BUFFER_AVAILABLE_CONTINUOUS_PORTION(&ZB_MACSPLIT_IOCTX().in_buffer);
  read_data_len = zb_mac_uart_read(ZB_RING_BUFFER_PUT_RESERVE(&ZB_MACSPLIT_IOCTX().in_buffer), read_data_len);
  ZB_RING_BUFFER_FLUSH_BATCH_PUT(&ZB_MACSPLIT_IOCTX().in_buffer, read_data_len);
*/
#endif
}


#ifdef ZB_MACSPLIT_HOST
static void uart_rx_handler(zb_uint8_t b)
{
  if (!ZB_RING_BUFFER_IS_FULL(&ZB_MACSPLIT_IOCTX().in_buffer))
  {
    ZB_RING_BUFFER_PUT(&ZB_MACSPLIT_IOCTX().in_buffer, b);
  }
}
#endif


/**
 * Write data from buf to com port (file name specified by @ref zb_mac_uart_path())
 *
 * @param buf - buffer with data to write
 *
 * @param len - length of buf
 *
 * @return nothing
 */
void zb_mac_uart_write(zb_uint8_t* buf, zb_uint_t len)
{
#if defined ZB_HAVE_ASYNC_SERIAL
  zb_osif_mserial_send_data(buf, len);
#else
  zb_osif_mserial_put_bytes(g_macsplit_port, buf, len);
#endif
}


/**
 * Close com port (file specified by @ref zb_mac_uart_path())
 *
 * @return nothing
 */
void zb_mac_uart_close(void)
{
  zb_osif_mserial_close(g_macsplit_port);
#ifdef ZB_MAC_TRANSPORT_UART_USE_RST_LINE
  zb_mac_uart_close_rst_line();
#endif  /* ZB_MAC_TRANSPORT_UART_USE_RST_LINE */
}

zb_serial_port_t zb_mac_get_mserial_port()
{
  return g_macsplit_port;
}

void zb_linux_transport_set_byte_received_cb(zb_callback_t hnd)
{
  zb_osif_mserial_set_byte_received_cb(zb_mac_get_mserial_port(), hnd);
}

#endif /*#ifdef ZB_TRANSPORT_LINUX_UART*/
