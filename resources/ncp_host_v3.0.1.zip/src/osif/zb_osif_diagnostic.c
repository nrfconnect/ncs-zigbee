/*
 * ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2023 DSR Corporation, Denver CO, USA.
 * http://www.dsr-zboss.com
 * http://www.dsr-corporation.com
 * All rights reserved.
 *
 *
 * Use in source and binary forms, redistribution in binary form only, with
 * or without modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 2. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 3. This software must only be used in or with a processor manufactured by Nordic
 *    Semiconductor ASA, or in or with a processor manufactured by a third party that
 *    is used in combination with a processor manufactured by Nordic Semiconductor.
 *
 * 4. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/* PURPOSE: diagnostic-related functions
*/

#define ZB_TRACE_FILE_ID 30014
#include "zb_common.h"

#if !defined(ZB_LITE_NO_DIAGNOSTIC) && defined(ZB_OSIF_DIAGNOSTIC_TOOLS)

zb_cli_transport_type_t zb_osif_cli_get_default_transport_type(void)
{
  zb_cli_transport_type_t cli_transport_type = ZB_CLI_TRANSPORT_TYPE_SYNC_SERIAL;

  const char *cli_transport_type_env = NULL;

#ifdef ZB_CLI_TRANSPORT_TYPE_ENV_NAME
  cli_transport_type_env = getenv(ZB_CLI_TRANSPORT_TYPE_ENV_NAME);
#endif

  if (cli_transport_type_env != NULL)
  {
    zb_char_t cli_transport_type_env_value[32];
    strncpy(cli_transport_type_env_value, cli_transport_type_env, ZB_ARRAY_SIZE(cli_transport_type_env_value));

    if (strncmp(cli_transport_type_env_value, "sync_serial", ZB_ARRAY_SIZE(cli_transport_type_env_value)) == 0)
    {
      cli_transport_type = ZB_CLI_TRANSPORT_TYPE_SYNC_SERIAL;
    }
    else if (strncmp(cli_transport_type_env_value, "async_serial", ZB_ARRAY_SIZE(cli_transport_type_env_value)) == 0)
    {
      cli_transport_type = ZB_CLI_TRANSPORT_TYPE_ASYNC_SERIAL;
    }
    else if (strncmp(cli_transport_type_env_value, "stdio", ZB_ARRAY_SIZE(cli_transport_type_env_value)) == 0)
    {
      cli_transport_type = ZB_CLI_TRANSPORT_TYPE_STDIO;
    }
    else
    {
      ZB_ASSERT(ZB_FALSE);
    }
  }
  else
  {
    cli_transport_type = ZB_CLI_TRANSPORT_TYPE_STDIO;
  }

  return cli_transport_type;
}


const char *zb_osif_cli_get_transport_serial_port(void)
{
  static const char* cli_transport_port = "zb_cli.pty";

  const char *cli_transport_port_env = getenv("ZB_CLI_SERIAL_PORT");

  if (cli_transport_port_env != NULL)
  {
    return cli_transport_port_env;
  }
  else
  {
    return cli_transport_port;
  }
}


const zb_uint8_t *zb_osif_cli_format_message(
  const zb_char_t *message,
  zb_size_t message_length,
  zb_size_t *prepared_message_length)
{
  *prepared_message_length = message_length;
  return (const zb_uint8_t*)message;
}

#endif /* !ZB_LITE_NO_DIAGNOSTIC && ZB_OSIF_DIAGNOSTIC_TOOLS */