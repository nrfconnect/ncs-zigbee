/*
 * ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2024 DSR Corporation, Denver CO, USA.
 * http://www.dsr-zboss.com
 * http://www.dsr-corporation.com
 * All rights reserved.
 *
 *
 * Use in source and binary forms, redistribution in binary form only, with
 * or without modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 2. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 3. This software must only be used in or with a processor manufactured by Nordic
 *    Semiconductor ASA, or in or with a processor manufactured by a third party that
 *    is used in combination with a processor manufactured by Nordic Semiconductor.
 *
 * 4. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#define ZB_TRACE_FILE_ID 30028

#include "zb_common.h"
#include "zb_ncp_serial.h"

#if defined(ZB_NCP_TRANSPORT_TYPE_SERIAL) || defined(ZB_NCP_TRANSPORT_TYPE_USERIAL)

/**
 * @brief Obtain a file name for an NCP serial port.
 *
 * Historically, ZBOSS had a lot of ways to define the filename. Now the rule is following:
 * 1) If ZB_NCP_PORT_ENV_NAME defined, use it as a variable name and read a file name from there
 * 2) (Legacy) Try to read a "NCP_SLAVE_PTY" variable, used to set a filename on a host side
 * 3) Use a default file name if defined by ZB_NCP_PORT_DEFAULT_PATH
 * 4) Throw an error
 *
 * @return const char*
 */
ZB_WEAK_PRE const char* ZB_WEAK zb_ncp_uart_path(void)
{
  char* filename = NULL;

#if defined ZB_NCP_PORT_ENV_NAME
  TRACE_MSG(TRACE_MAC2, "Getting a file name from the environment variable %s", (FMT__P, ZB_NCP_PORT_ENV_NAME));
  filename = getenv(ZB_NCP_PORT_ENV_NAME);
#endif /* defined SERIAL_ENV_NAME */

  /* Legacy step, should be removed in future. */
  if (filename == NULL)
  {
    TRACE_MSG(TRACE_MAC2, "Getting a file name from the environment variable NCP_SLAVE_PTY", (FMT__0));
    filename = getenv("NCP_SLAVE_PTY");
  }

#if defined(ZB_NCP_PORT_DEFAULT_PATH)
  if (filename == NULL)
  {
    TRACE_MSG(TRACE_MAC2, "Using a %s file name defined in the MACSPLIT_DEFAULT_PATH", (FMT__P, ZB_NCP_PORT_DEFAULT_PATH));
    filename = ZB_NCP_PORT_DEFAULT_PATH;
  }
#endif

  ZB_VERIFY(filename != NULL, RET_FILE_NOT_FOUND);

  TRACE_MSG(TRACE_MAC2, "NCP serial file name is %s", (FMT__P, filename));
  return filename;
}

#endif /* ZB_NCP_TRANSPORT_TYPE_SERIAL || ZB_NCP_TRANSPORT_TYPE_USERIAL */
