/*
 * ZBOSS Zigbee software protocol stack
 *
 * Copyright (c) 2012-2024 DSR Corporation, Denver CO, USA.
 * http://www.dsr-zboss.com
 * http://www.dsr-corporation.com
 * All rights reserved.
 *
 *
 * Use in source and binary forms, redistribution in binary form only, with
 * or without modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 2. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 3. This software must only be used in or with a processor manufactured by Nordic
 *    Semiconductor ASA, or in or with a processor manufactured by a third party that
 *    is used in combination with a processor manufactured by Nordic Semiconductor.
 *
 * 4. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/* PURPOSE: serial transport, common
*/

#define _XOPEN_SOURCE 600
#define _DEFAULT_SOURCE
#define ZB_TRACE_FILE_ID 30016
#include "zb_common.h"

#ifdef MACOSX
#ifndef _DARWIN_C_SOURCE
#define _DARWIN_C_SOURCE
#endif /* !_DARWIN_C_SOURCE */
#endif /* MACOSX */

#include <stdlib.h>
#include <string.h>

#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <termios.h>

#include <linux/limits.h>

#ifndef ZB_SERIAL_PATH_SIZE
#define ZB_SERIAL_PATH_SIZE PATH_MAX
#endif

#define ZB_SERIAL_RX_BUF_SIZE 256
#define ZB_SERIAL_INSTANCE_MAX 5

typedef struct serial_ctx_s
{
#if defined ZB_HAVE_ASYNC_SERIAL
  zb_uint8_t *rx_buf;
  zb_size_t rx_buf_size;
  zb_uindex_t rx_buf_offset;
  zb_size_t rx_buf_remaining_size;
  zb_mserial_recv_data_cb_t rx_done_cb;
  zb_serial_send_data_cb_t tx_done_cb;
#else /* !defined ZB_HAVE_ASYNC_SERIAL */
  zb_uint8_t rx_buf[ZB_SERIAL_RX_BUF_SIZE];
  zb_callback_t rx_byte_cb;
#endif /* !defined ZB_HAVE_ASYNC_SERIAL */
  int serial_fd;
  zb_bool_t inited;
  char portname[ZB_SERIAL_PATH_SIZE];
} serial_ctx_t;

static serial_ctx_t serial_ctx[ZB_SERIAL_INSTANCE_MAX];
static zb_bool_t was_initialized = ZB_FALSE;

static zb_serial_port_t get_free_slot();
static zb_serial_port_t get_serial_port_by_fd(int fd);
static zb_serial_port_t osif_mserial_ctx_init(int fd, const char* portname);
static int osif_mserial_deinit(zb_serial_port_t instance);
static zb_ret_t set_serial_port_params(int fd, zb_uint32_t speed);
static zb_uint32_t zb_osif_mserial_convert_baudrate(zb_uint32_t value);
static zb_serial_port_t zb_osif_mserial_get_instance_by_name(const char* portname);

/* to compile at r22 declare prototypes */
int osif_open_n_config_serial_port(const char* filename, zb_uint32_t speed);
int osif_create_master_pty(const char *symlink_name, zb_uint32_t speed);

zb_serial_port_t zb_osif_mserial_open(const char *portname, zb_uint32_t speed)
{
  int instance;
  int s_fd;

  ZB_ASSERT(portname != NULL);
  TRACE_MSG(TRACE_OSIF1, ">> zb_osif_mserial_init, portname=%s", (FMT__P, portname));

  instance = zb_osif_mserial_get_instance_by_name(portname);
  if (instance >= 0)
  {
    zb_osif_mserial_close(instance);
  }

  s_fd = osif_open_n_config_serial_port(portname, speed);
  if (s_fd == -1)
  {
    ZB_ERROR_RAISE(ZB_ERROR_SEVERITY_MAJOR,
                    ERROR_CODE(ERROR_CATEGORY_SERIAL, ZB_ERROR_SERIAL_INIT_FAILED),
                    (void*)errno);
    return SERIAL_PORT_INVALID;
  }

  return osif_mserial_ctx_init(s_fd, portname);
}

zb_serial_port_t zb_osif_mserial_create_pty(const char *symlink, zb_uint32_t speed)
{
  int master_pty_fd;
  zb_serial_port_t port;

  ZB_ASSERT(symlink != NULL);
  TRACE_MSG(TRACE_OSIF1, ">> zb_osif_mserial_init, portname=%s", (FMT__P, symlink));

  master_pty_fd = osif_create_master_pty(symlink, speed);
  ZB_ASSERT(master_pty_fd != -1);

  port = osif_mserial_ctx_init(master_pty_fd, "master_pty");

  TRACE_MSG(TRACE_OSIF1, "<< zb_osif_mserial_init port %hd has been initialized", (FMT__H, port));

  return port;
}

void zb_osif_mserial_close(zb_serial_port_t instance)
{
  if (instance != SERIAL_PORT_INVALID)
  {
    int fd = osif_mserial_deinit(instance);
    close(fd);
  }
}

static zb_ret_t send_data(zb_serial_port_t instance, const zb_uint8_t *buf, zb_ushort_t len)
{
  zb_ret_t ret = RET_OK;
  zb_size_t bytes_written = 0;

  ZB_ASSERT(instance < ZB_SERIAL_INSTANCE_MAX && instance != SERIAL_PORT_INVALID);
  ZB_ASSERT(serial_ctx[instance].inited);

  if (TRACE_ENABLED(TRACE_OSIF4))
  {
    dump_hex_data(TRACE_SUBSYSTEM_COMMON, 4, buf, (zb_ushort_t)len);
  }

  do
  {
    errno = 0;
    bytes_written = write(serial_ctx[instance].serial_fd, buf, len);
    if (bytes_written > 0)
    {
      buf += bytes_written;
      len -= bytes_written;
    }
    else
    {
      if (errno != EAGAIN && errno != EINTR)
      {
        TRACE_MSG(TRACE_ERROR, "failed to write to file %d, errno: %d",
                  (FMT__D_D, serial_ctx[instance].serial_fd, errno));
        break;
      }
    }
  } while (len);

  if (len)
  {
    ret = RET_ERROR;
  }

  return ret;
}


#if defined ZB_HAVE_ASYNC_SERIAL
static void free_rx_buffer(zb_serial_port_t instance)
{
  ZB_ASSERT(instance < ZB_SERIAL_INSTANCE_MAX && instance != SERIAL_PORT_INVALID);
  ZB_ASSERT(serial_ctx[instance].inited);

  serial_ctx[instance].rx_buf = NULL;
  serial_ctx[instance].rx_buf_size = 0;
  serial_ctx[instance].rx_buf_remaining_size = 0;
  serial_ctx[instance].rx_buf_offset = 0;
}


void zb_osif_mserial_recv_data(zb_serial_port_t instance, zb_uint8_t *buf, zb_ushort_t len)
{
  TRACE_MSG(TRACE_OSIF2, ">> zb_osif_mserial_recv_data, instance %hd, buf %p, len %d", (FMT__H_P_D, instance, buf, len));

  // ZB_ASSERT(instance < ZB_SERIAL_INSTANCE_MAX && instance != SERIAL_PORT_INVALID);
  // ZB_ASSERT(serial_ctx[instance].inited);
  /* It is possible that NCP calls this functions when port has not been opened yet. Just ignore such case */
  if (instance >= ZB_SERIAL_INSTANCE_MAX || instance == SERIAL_PORT_INVALID)
  {
    return;
  }

  if (serial_ctx[instance].inited)
  {
    serial_ctx[instance].rx_buf = buf;
    serial_ctx[instance].rx_buf_size = len;
    serial_ctx[instance].rx_buf_offset = 0;
    serial_ctx[instance].rx_buf_remaining_size = len;
  }
  else
  {
    TRACE_MSG(TRACE_ERROR, "Read error: serial transport is not initialized!", (FMT__0));
  }

  TRACE_MSG(TRACE_OSIF4, "<< zb_osif_mserial_recv_data", (FMT__0));
}


void zb_osif_mserial_set_cb_recv_data(zb_serial_port_t instance, zb_mserial_recv_data_cb_t cb)
{
  TRACE_MSG(TRACE_OSIF2, "zb_osif_mserial_set_cb_recv_data, instance %hd, cb %p", (FMT__H_P, instance, cb));

  // ZB_ASSERT(instance < ZB_SERIAL_INSTANCE_MAX && instance != SERIAL_PORT_INVALID);
  // ZB_ASSERT(serial_ctx[instance].inited);
  /* It is possible that NCP calls this functions when port has not been opened yet. Just ignore such case */
  if (instance < ZB_SERIAL_INSTANCE_MAX && instance != SERIAL_PORT_INVALID && serial_ctx[instance].inited)
  {
    serial_ctx[instance].rx_done_cb = cb;
  }
}


void zb_osif_mserial_send_data(zb_serial_port_t instance, zb_uint8_t *buf, zb_ushort_t len)
{
  zb_ret_t status;

  TRACE_MSG(TRACE_OSIF4, ">> zb_osif_mserial_send_data, instance %hd, buf %p, len %d", (FMT__H_P_D, instance, buf, len));

  // ZB_ASSERT(instance < ZB_SERIAL_INSTANCE_MAX && instance != SERIAL_PORT_INVALID);
  // ZB_ASSERT(serial_ctx[instance].inited);
  /* It is possible that NCP calls this functions when port has not been opened yet. Just ignore such case */
  if (instance >= ZB_SERIAL_INSTANCE_MAX || instance == SERIAL_PORT_INVALID)
  {
    return;
  }

  if (serial_ctx[instance].inited)
  {

    status = send_data(instance, buf, len);
    ZB_ASSERT(status == RET_OK);

    if (serial_ctx[instance].tx_done_cb)
    {
      ZB_SCHEDULE_CALLBACK(serial_ctx[instance].tx_done_cb, SERIAL_SEND_SUCCESS);
    }
  }
  else
  {
    TRACE_MSG(TRACE_ERROR, "Send error: serial transport is not initialized!", (FMT__0));

    if (serial_ctx[instance].tx_done_cb)
    {
      ZB_SCHEDULE_CALLBACK(serial_ctx[instance].tx_done_cb, SERIAL_SEND_ERROR);
    }
  }

  TRACE_MSG(TRACE_OSIF4, "<< zb_osif_mserial_send_data", (FMT__0));
}


void zb_osif_mserial_set_cb_send_data(zb_serial_port_t instance, zb_serial_send_data_cb_t cb)
{
  TRACE_MSG(TRACE_OSIF2, "zb_osif_mserial_set_cb_send_data, instance %hd, cb %p", (FMT__H_P, instance, cb));

  // ZB_ASSERT(instance < ZB_SERIAL_INSTANCE_MAX && instance != SERIAL_PORT_INVALID);
  // ZB_ASSERT(serial_ctx[instance].inited);

  /* It is possible that NCP calls this functions when port has not been opened yet. Just ignore such case */

  if (instance < ZB_SERIAL_INSTANCE_MAX && instance != SERIAL_PORT_INVALID && serial_ctx[instance].inited)
  {
    serial_ctx[instance].tx_done_cb = cb;
  }
}


static void handle_read_event(osif_ipc_handle_t handle, zb_uint8_t event_mask)
{
  ssize_t bytes_read = 0;
  zb_serial_port_t index = get_serial_port_by_fd(handle);

  /* In normal case event_mask == OSIF_IPC_SIGNAL_RX.
   * But in case of error (or EOF) it can include other signals (ERR and HUP).
   * In such cases `read` will return bytes_read <= 0 and we will handle this case below. */
  /* ZB_ASSERT(event_mask == OSIF_IPC_SIGNAL_RX); */

  TRACE_MSG(TRACE_OSIF4, ">> handle_read_event handle %d, event_mask 0x%02x", (FMT__D_D, handle, event_mask));

  if (index != SERIAL_PORT_INVALID)
  {
    if (!serial_ctx[index].rx_buf)
    {
      TRACE_MSG(TRACE_ERROR, "no rx buf!", (FMT__0));
    }
    else
    {
      errno = 0;

      do
      {
        bytes_read = read(serial_ctx[index].serial_fd,
                          serial_ctx[index].rx_buf + serial_ctx[index].rx_buf_offset,
                          serial_ctx[index].rx_buf_remaining_size);
      } while (bytes_read < 0 && errno == EINTR);

      TRACE_MSG(TRACE_OSIF4, "received %d bytes", (FMT__D, bytes_read));

      if (bytes_read > 0)
      {
        if (TRACE_ENABLED(TRACE_OSIF4))
        {
          dump_hex_data(TRACE_SUBSYSTEM_COMMON, 4,
                        serial_ctx[index].rx_buf + serial_ctx[index].rx_buf_offset,
                        (zb_ushort_t)bytes_read);
        }

        serial_ctx[index].rx_buf_offset += bytes_read;
        serial_ctx[index].rx_buf_remaining_size -= bytes_read;

        /* Note: that if() makes impossible using of that cpode for MAC split
        * transport. MAC split low level does not know how many bytes it must
        * read and wants to read up to free stace in the ring buffer.
        * Will NCP protocol logic be broken if we call its callback when not all bytes have been read?
        */
        if (!serial_ctx[index].rx_buf_remaining_size)
        {
          zb_uint8_t* buf = serial_ctx[index].rx_buf;
          zb_size_t buf_size = serial_ctx[index].rx_buf_size;

          free_rx_buffer(index);
          if (serial_ctx[index].rx_done_cb)
          {
            serial_ctx[index].rx_done_cb(index, buf, (zb_ushort_t)buf_size);
          }
        }
      }
      else
      {
        TRACE_MSG(TRACE_ERROR, "read error, errno: %d", (FMT__D, errno));
        ZB_ERROR_RAISE(ZB_ERROR_SEVERITY_MAJOR,
                      ERROR_CODE(ERROR_CATEGORY_SERIAL, ZB_ERROR_SERIAL_READ_FAILED),
                      NULL);
      }
    }
  }

  TRACE_MSG(TRACE_OSIF4, "<< handle_read_event", (FMT__0));
}

#else /* !defined ZB_HAVE_ASYNC_SERIAL */

void zb_osif_mserial_set_byte_received_cb(zb_serial_port_t instance, zb_callback_t cb)
{
  TRACE_MSG(TRACE_OSIF2, "zb_osif_set_uart_byte_received_cb, instance %hd, cb %p", (FMT__H_P, instance, cb));

  // ZB_ASSERT(instance < ZB_SERIAL_INSTANCE_MAX && instance != SERIAL_PORT_INVALID);
  // ZB_ASSERT(serial_ctx[instance].inited);
  /* It is possible that NCP calls this functions when port has not been opened yet. Just ignore such case */

  if (instance < ZB_SERIAL_INSTANCE_MAX && instance != SERIAL_PORT_INVALID && serial_ctx[instance].inited)
  {
    serial_ctx[instance].rx_byte_cb = cb;
  }
}


void zb_osif_mserial_put_bytes(zb_serial_port_t instance, const zb_uint8_t *buf, zb_short_t len)
{
  zb_ret_t status = RET_ERROR;

  TRACE_MSG(TRACE_OSIF4, ">> zb_osif_mserial_put_bytes, instance %hd, buf %p, len %d", (FMT__H_P_D, instance, buf, len));

  ZB_ASSERT(instance < ZB_SERIAL_INSTANCE_MAX);
  ZB_ASSERT(serial_ctx[instance].inited);

  status = send_data(instance, buf, len);

  ZB_ASSERT(status == RET_OK);

  TRACE_MSG(TRACE_OSIF4, "<< zb_osif_mserial_put_bytes", (FMT__0));
}


static void handle_read_event(osif_ipc_handle_t handle, zb_uint8_t event_mask)
{
  ssize_t bytes_read = 0;
  zb_serial_port_t index = get_serial_port_by_fd(handle);

  /* In normal case event_mask == OSIF_IPC_SIGNAL_RX.
   * But in case of error (or EOF) it can include other signals (ERR and HUP).
   * In such cases `read` will return bytes_read <= 0 and we will handle this case below. */
  /* ZB_ASSERT(event_mask == OSIF_IPC_SIGNAL_RX); */

  TRACE_MSG(TRACE_OSIF4, ">> handle_read_event handle %d, event_mask 0x%02x", (FMT__D_D, handle, event_mask));

  if (index != SERIAL_PORT_INVALID)
  {
    bytes_read = read(serial_ctx[index].serial_fd,
                      serial_ctx[index].rx_buf,
                      ZB_SERIAL_RX_BUF_SIZE);

    TRACE_MSG(TRACE_OSIF4, "received %d bytes", (FMT__D, bytes_read));

    /* Normally we came here on RX signal and then we expect that `read` will give
    * us some data. That's why bytes_read == 0 is interpreted as error */
    if (bytes_read > 0)
    {
      ssize_t i = 0;

      if (TRACE_ENABLED(TRACE_OSIF4))
      {
        for (i = 0; i < bytes_read; i++)
        {
          TRACE_MSG(TRACE_OSIF4, "received byte: 0x%x", (FMT__D, serial_ctx[index].rx_buf[i]));
        }
      }

      if (serial_ctx[index].rx_byte_cb)
      {
        for (i = 0; i < bytes_read; i++)
        {
          serial_ctx[index].rx_byte_cb(serial_ctx[index].rx_buf[i]);
        }
      }
    }
    else
    {
      if (errno == EIO)
      {
        TRACE_MSG(TRACE_OSIF4, "read error, errno: %d", (FMT__D, errno));
      }
      else
      {
        TRACE_MSG(TRACE_ERROR, "read error, event_mask 0x%02x, errno: %d", (FMT__D_D, event_mask, errno));
      }

      ZB_ERROR_RAISE(ZB_ERROR_SEVERITY_MAJOR,
                    ERROR_CODE(ERROR_CATEGORY_SERIAL, ZB_ERROR_SERIAL_READ_FAILED),
                    NULL);
    }
  }
  TRACE_MSG(TRACE_OSIF4, "<< handle_read_event", (FMT__0));
}

#endif /* !defined ZB_HAVE_ASYNC_SERIAL */


static zb_serial_port_t osif_mserial_ctx_init(int fd, const char* portname)
{
  zb_ret_t status = RET_ERROR;
  zb_serial_port_t index;

  ZB_ASSERT(fd >= 0);

  if (!was_initialized)
  {
    ZB_BZERO(&serial_ctx[0], sizeof(serial_ctx));
    was_initialized = ZB_TRUE;
  }

  index = get_free_slot();
  if (index == SERIAL_PORT_INVALID)
  {
    return SERIAL_PORT_INVALID;
  }

  ZB_BZERO(&serial_ctx[index], sizeof(serial_ctx_t));

  serial_ctx[index].serial_fd = fd;
  ZB_ASSERT_COMPILE_TIME(sizeof(serial_ctx[index].portname) == ZB_SERIAL_PATH_SIZE);
  strncpy(serial_ctx[index].portname, portname, ZB_SERIAL_PATH_SIZE);
  serial_ctx[index].portname[ZB_SERIAL_PATH_SIZE - 1] = 0;

  /* We don't need to specify other signals like ERR and HUP since they will be emitted anyway */
  status = osif_ipc_add_io_handler(fd,
                                         OSIF_IPC_SIGNAL_RX,
                                         handle_read_event);
  ZB_ASSERT(status == RET_OK);

  serial_ctx[index].inited = ZB_TRUE;
  return index;
}


static int osif_mserial_deinit(zb_serial_port_t instance)
{
  ZB_ASSERT(instance < ZB_SERIAL_INSTANCE_MAX && instance != SERIAL_PORT_INVALID);
  if (serial_ctx[instance].inited)
  {
    osif_ipc_remove_io_handler(serial_ctx[instance].serial_fd);
    serial_ctx[instance].inited = ZB_FALSE;
    return serial_ctx[instance].serial_fd;
  }
  return -1;
}

static zb_serial_port_t get_serial_port_by_fd(int fd)
{
  zb_uindex_t i;
  for (i = 0; i < ZB_SERIAL_INSTANCE_MAX; i++)
  {
    if (serial_ctx[i].inited && serial_ctx[i].serial_fd == fd)
    {
      return i;
    }
  }
  return SERIAL_PORT_INVALID;
}

static zb_serial_port_t get_free_slot()
{
  zb_uindex_t i;
  for (i = 0; i < ZB_SERIAL_INSTANCE_MAX; i++)
  {
    if (!serial_ctx[i].inited)
    {
      return i;
    }
  }
  return SERIAL_PORT_INVALID;
}

static zb_serial_port_t zb_osif_mserial_get_instance_by_name(const char* portname)
{
  zb_uindex_t i;
  if (portname == NULL)
  {
    return SERIAL_PORT_INVALID;
  }

  ZB_ASSERT_COMPILE_TIME(sizeof(serial_ctx[0].portname) == ZB_SERIAL_PATH_SIZE);
  for (i = 0; i < ZB_SERIAL_INSTANCE_MAX; i++)
  {
    if (serial_ctx[i].inited && !strncmp(portname, serial_ctx[i].portname, ZB_SERIAL_PATH_SIZE))
    {
      return i;
    }
  }

  return SERIAL_PORT_INVALID;
}

zb_serial_port_t zb_osif_mserial_get_instance_by_fd(int fd)
{
  zb_uindex_t i;

  ZB_ASSERT(fd >= 0);

  for (i = 0; i < ZB_SERIAL_INSTANCE_MAX; i++)
  {
    if (serial_ctx[i].inited && serial_ctx[i].serial_fd == fd)
    {
      return i;
    }
  }

  return SERIAL_PORT_INVALID;
}


static zb_uint32_t zb_osif_mserial_convert_baudrate(zb_uint32_t value)
{
    zb_uint32_t ts_baud = B115200;

    switch (value) {
      case 38400UL:
        ts_baud = B38400;
        break;
      case 57600UL:
        ts_baud = B57600;
        break;
      case 115200UL:
        ts_baud = B115200;
        break;
      case 230400UL:
        ts_baud = B230400;
        break;
#ifndef MACOSX
      case 460800UL:
        ts_baud = B460800;
        break;
      case 500000UL:
        ts_baud = B500000;
        break;
      case 576000UL:
        ts_baud = B576000;
        break;
      case 921600UL:
        ts_baud = B921600;
        break;
      case 1000000UL:
        ts_baud = B1000000;
        break;
      case 1152000UL:
        ts_baud = B1152000;
        break;
#endif
      default:
        /* Unsupported baud rate. Please add it to the switch above */
        ZB_ASSERT(false);
    }

    return ts_baud;
}

int osif_open_n_config_serial_port(const char* filename, zb_uint32_t speed)
{
  zb_ret_t status;
  int fd = -1;

  do
  {
    if (filename == NULL)
    {
      TRACE_MSG(TRACE_ERROR, "Serial port name is not set, failed to open", (FMT__0));
      return -1;
    }

    do
    {
      errno = 0;
      fd = open(filename, O_RDWR | O_NOCTTY | O_NONBLOCK);
    } while (fd < 0 && errno == EINTR);

    if (fd == -1)
    {
      TRACE_MSG(TRACE_ERROR, "failed to open file %s, errno: %d", (FMT__P_D, filename, errno));
      break;
    }

    /* Flush IO buffers so we don't receive buffered messaged which
       were sent before we opened the port.
       Needed for NCP: we need to flush buffers so host don't receive many duplicates
       of unsolicited NCP Module Reset Response */
    osif_usleep(10000);
    tcflush(fd, TCIOFLUSH);

    status = set_serial_port_params(fd, speed);
    if (status != RET_OK)
    {
      close(fd);
      fd = -1;
      break;
    }
  } while(0);

  return fd;
}


static zb_ret_t set_serial_port_params(int fd, zb_uint32_t speed)
{
  struct termios ts;
  zb_ret_t ret = RET_ERROR;
  int fcntl_return_code = 0;

  do
  {
    if (tcgetattr(fd, &ts) < 0)
    {
      TRACE_MSG(TRACE_ERROR, "failed to get terminal attributes, errno: %d", (FMT__D, errno));
      break;
    }

    cfmakeraw(&ts);

    cfsetospeed(&ts, zb_osif_mserial_convert_baudrate(speed));
    cfsetispeed(&ts, zb_osif_mserial_convert_baudrate(speed));
    ts.c_cflag &= ~(CSIZE | PARENB);
    ts.c_cflag |= CS8 | CREAD | HUPCL | CLOCAL;
#ifdef ZB_MAC_TRANSPORT_UART_CRTSCTS
    /* TODO: make it configurable */
    ts.c_cflag |= CRTSCTS;
#endif
    errno = 0;

    if (tcsetattr(fd, TCSANOW, &ts))
    {
      TRACE_MSG(TRACE_ERROR, "failed to set terminal attributes, errno: %d", (FMT__D, errno));
      break;
    }
    /* Port is opened with O_NONBLOCK flag */
    if ((fcntl_return_code = fcntl(fd, F_GETFL, 0)) < 0)
    {
      TRACE_MSG(TRACE_ERROR, "fcntl get error", (FMT__0));
    }
    else
    {
      fcntl_return_code &= ~O_NONBLOCK;
      if (fcntl(fd, F_SETFL, fcntl_return_code) < 0)
      {
        TRACE_MSG(TRACE_ERROR, "fcntl set error", (FMT__0));
      }
    }

    ret = RET_OK;
  } while(0);

  return ret;
}

static zb_ret_t set_master_pty_params(int fd, zb_uint32_t speed)
{
  struct termios ts;
  zb_ret_t ret = RET_ERROR;

  do
  {
    if (tcgetattr(fd, &ts) < 0)
    {
      TRACE_MSG(TRACE_ERROR, "failed to get terminal attributes, errno: %d", (FMT__D, errno));
      break;
    }

    cfmakeraw(&ts);

    /* TODO: make it configurable? */
    cfsetospeed(&ts, zb_osif_mserial_convert_baudrate(speed));
    cfsetispeed(&ts, zb_osif_mserial_convert_baudrate(speed));

    if (tcsetattr(fd, TCSANOW, &ts))
    {
      TRACE_MSG(TRACE_ERROR, "failed to set terminal attributes, errno: %d", (FMT__D, errno));
      break;
    }

    ret = RET_OK;
  } while(0);

  return ret;
}

static zb_ret_t create_slave_pty_symlink(const char *slave_pty_name, const char *symlink_name)
{
  struct stat stat_buf;
  zb_ret_t ret = RET_ERROR;

  ZB_ASSERT(slave_pty_name);
  ZB_ASSERT(symlink_name != NULL);

  do
  {
    TRACE_MSG(TRACE_MAC2, "Opening a port %s", (FMT__P, symlink_name));

    if (!lstat(symlink_name, &stat_buf))
    {
      if (stat_buf.st_mode & S_IFLNK)
      {
        char referred_filename[ZB_MAX_FILE_PATH_SIZE];
        ssize_t filename_size = readlink(symlink_name, referred_filename, ZB_MAX_FILE_PATH_SIZE);

        if (filename_size == ZB_MAX_FILE_PATH_SIZE)
        {
          TRACE_MSG(TRACE_ERROR, "readlink failed, too long filename", (FMT__0));
          break;
        }

        if (filename_size == -1)
        {
          TRACE_MSG(TRACE_ERROR, "readlink failed, errno: %s", (FMT__D, errno));
          break;
        }

        referred_filename[filename_size] = '\0';

        if (!access(referred_filename, F_OK)
            && strcmp(slave_pty_name, referred_filename))
        {
            TRACE_MSG(TRACE_ERROR, "%s exists, refers to %s, can't create a symlink to slave pty",
                      (FMT__P_P, symlink_name, referred_filename));
            break;
        }

        if (unlink(symlink_name))
        {
          TRACE_MSG(TRACE_ERROR, "failed to unlink %s", (FMT__P, symlink_name));
          break;
        }
      }
      else
      {
        TRACE_MSG(TRACE_ERROR, "%s exists, can't create a symlink to slave pty",
                  (FMT__P, symlink_name));
        break;
      }
    }

    if (symlink(slave_pty_name, symlink_name))
    {
      TRACE_MSG(TRACE_ERROR, "failed to create symlink %s to %s, errno: %d",
                (FMT__P_P_D, symlink_name, slave_pty_name, errno));
      break;
    }

    TRACE_MSG(TRACE_OSIF2, "created symlink %s to %s", (FMT__P_P, symlink_name, slave_pty_name));

    ret = RET_OK;
  } while(0);

  return ret;
}

int osif_create_master_pty(const char *symlink_name, zb_uint32_t speed)
{
  const char *slave_pty_name = NULL;
  int master_pty_fd;
  int ret = -1;

  do
  {
    master_pty_fd = posix_openpt(O_RDWR | O_NOCTTY);
    if (master_pty_fd == -1)
    {
      TRACE_MSG(TRACE_ERROR, "failed to open the master pty, errno: %d", (FMT__D, errno));
      break;
    }

    if (set_master_pty_params(master_pty_fd, speed) != RET_OK)
    {
      TRACE_MSG(TRACE_ERROR, "failed to set master pty params", (FMT__0));
      break;
    }

    if (grantpt(master_pty_fd) == -1)
    {
      TRACE_MSG(TRACE_ERROR, "failed to grant access to the slave pty, errno: %d", (FMT__D, errno));
      break;
    }

    if (unlockpt(master_pty_fd) == -1)
    {
      TRACE_MSG(TRACE_ERROR, "failed to unlock the slave pty, errno: %d", (FMT__D, errno));
      break;
    }

    slave_pty_name = ptsname(master_pty_fd);
    if (!slave_pty_name)
    {
      TRACE_MSG(TRACE_ERROR, "failed to get the slave pty name", (FMT__0));
      break;
    }
    TRACE_MSG(TRACE_OSIF2, "slave pty: %s", (FMT__P, slave_pty_name));

    if (create_slave_pty_symlink(slave_pty_name, symlink_name) != RET_OK)
    {
      TRACE_MSG(TRACE_ERROR, "failed to create pty slave symlink", (FMT__0));
      break;
    }

    ret = master_pty_fd;
  } while(0);

  TRACE_MSG(TRACE_OSIF1, "<< open_master_pty, master_pty_fd %d", (FMT__D, ret));

  return ret;
}


void osif_register_hup_on_slave_pty(int master_pty_fd)
{
  const char *slave_pty_name = NULL;
  slave_pty_name = ptsname(master_pty_fd);

  if (slave_pty_name != NULL)
  {
    int fd = open(slave_pty_name, O_RDWR | O_NOCTTY);
    if (fd >= 0)
    {
      close(fd);
    }
  }
}


int osif_is_hup_on_fd(int fd)
{
  struct pollfd pfd;

  memset(&pfd, 0, sizeof(pfd));
  pfd.fd = fd;
  pfd.events = POLLHUP;

  poll(&pfd, 1, 0);

  if (!(pfd.revents & POLLHUP))
  {
    return 0;
  }
  else
  {
    return 1;
  }
}
