ZBOSS NCP Host release notes
############################

For the release notes, see the online ZBOSS NCP Host documentation at https://nrfconnect.github.io/ncs-zigbee/zboss/4.1.4.2/zboss_ncp_host_intro.html
